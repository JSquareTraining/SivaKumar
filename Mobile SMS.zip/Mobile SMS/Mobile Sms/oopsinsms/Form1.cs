﻿using System;
using System.IO;
using System.Windows.Forms;

namespace oopsinsms
{
    #region(All Coding)
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
        sms sms = new sms();
        #region("Registration")
        private void btn14_Click(object sender, EventArgs e)
        {

            if (txtbox3.Text != "" && tabPage4.Text != "" && tabPage5.Text != "" && txtbox6.Text != "")
            {
                if (radiobtn1.Checked == true || radiobtn2.Checked == true)
                {
                    string s;
                    if (radiobtn1.Checked == true)
                    {
                        s = radiobtn1.Text;
                    }
                    else
                    {
                        s = radiobtn2.Text;
                    }
                    Directory.CreateDirectory("E:\\siva\\oopsinsms\\sms\\" + txtbox4.Text);
                    DirectoryInfo d = new DirectoryInfo("E:\\siva\\oopsinsms\\sms\\" + txtbox4.Text);
                    d.CreateSubdirectory("inbox");
                    d.CreateSubdirectory("sent");
                    sms.filewrite("E:\\siva\\oopsinsms\\sms\\" + txtbox4.Text + "\\" + txtbox5.Text + ".txt", txtbox3.Text, s, txtbox4.Text, txtbox5.Text, txtbox6.Text);
                    MessageBox.Show("Sucessfully Registered");
                    tabControl1.TabPages.Remove(tabPage6);
                    tabControl1.TabPages.Insert(0, tabPage1);

                }
                else
                {
                    MessageBox.Show("Information Not Completed");
                }
            }
            else
            {
                MessageBox.Show("Information Not Completed");
            }
        }
       #endregion
        #region(SendSms)
        private void btn15_Click(object sender, EventArgs e)
        {
            if (txtbox7.Text != "" && txtbox8.Text != "" && richtxtbx3.Text != "")
            {
                Directory.CreateDirectory("E:\\siva\\oopsinsms\\sms\\" + txtbox7.Text + "\\inbox\\" + txtbox1.Text);
                sms.filewrite("E:\\siva\\oopsinsms\\sms\\" + txtbox7.Text + "\\inbox\\" + txtbox1.Text + "\\" + txtbox8.Text + ".txt", richtxtbx3.Text);
                Directory.CreateDirectory("E:\\siva\\oopsinsms\\sms\\" + txtbox1.Text + "\\sent\\" + txtbox7.Text);
                sms.filewrite("E:\\siva\\oopsinsms\\sms\\" + txtbox1.Text + "\\Sent\\" + txtbox7.Text + "\\" + txtbox8.Text + ".txt", richtxtbx3.Text);
                MessageBox.Show("Message Sucessfully Sent");
            }
            else
            {
                MessageBox.Show("Enter All Fields");
            }
        }
        #endregion
        #region(LoginProcess)
        private void btn1_Click(object sender, EventArgs e)
        {
            if (txtbox1.Text != "" && txtbox2.Text != "")
            {
                if (Directory.Exists("E:\\siva\\oopsinsms\\sms\\" + txtbox1.Text) && File.Exists("E:\\siva\\oopsinsms\\sms\\"+txtbox1.Text+"\\"+ txtbox2.Text + ".txt"))
                {
                    tabControl1.TabPages.Remove(tabPage1);
                    tabControl1.TabPages.Insert(0, tabPage2);
                }
                else
                {
                    MessageBox.Show("Wrong User");
                }
            }
            else
                MessageBox.Show("Enter MobileNo&Password");
        }
        #endregion
        #region("Way2Sms(Tabpage2)Insert&RemoveProcess")
        private void lbl5_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Remove(tabPage1);
            tabControl1.TabPages.Insert(0, tabPage6);
        }

        private void btn2_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Insert(0, tabPage4);
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Remove(tabPage3);
            tabControl1.TabPages.Remove(tabPage4);
            tabControl1.TabPages.Remove(tabPage5);
            tabControl1.TabPages.Remove(tabPage6);
        }
        #endregion
        #region("inboxprocess")
        private void listbx1_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo dd = new DirectoryInfo("E:\\siva\\oopsinsms\\sms\\" + txtbox1.Text + "\\inbox\\"+listbx1.SelectedItem);
            foreach ( FileInfo vv in dd.GetFiles())
            {
                string s = vv.Name;
                string[] dk = s.Split('.');
                listbx3.Items.Add(dk[0].ToString());
            }
        }
        private void btn3_Click(object sender, EventArgs e)
        {
                
                DirectoryInfo d = new DirectoryInfo("E:\\siva\\oopsinsms\\sms\\" + txtbox1.Text + "\\inbox");
                foreach (DirectoryInfo v in d.GetDirectories())
                {
                    listbx1.Items.Add(v);
                }
                lbl8.Text = listbx1.Items.Count.ToString();
                tabControl1.TabPages.Remove(tabPage2);
                tabControl1.TabPages.Insert(0, tabPage3);
                if (listbx1.Items.Count == 0)
                {
                    btn6.Enabled = false;
                    btn7.Enabled = false;
                }
                else
                {
                    btn6.Enabled = true;
                    btn7.Enabled = false;
                }
           
        }

        private void listbx3_SelectedIndexChanged(object sender, EventArgs e)
        {
            richtxtbx1.Text = sms.fileRead("E:\\siva\\oopsinsms\\sms\\" + txtbox1.Text + "\\inbox\\" + listbx1.SelectedItem + "\\" + listbx3.SelectedItem+".txt");
            if (richtxtbx1.Text != "")
            {
                btn7.Enabled = true;
            }
                   }
        #endregion
        #region(Sentprocess)
        private void btn4_Click(object sender, EventArgs e)
        {
            DirectoryInfo d = new DirectoryInfo("E:\\siva\\oopsinsms\\sms\\" + txtbox1.Text + "\\sent");
            foreach (DirectoryInfo v in d.GetDirectories())
            {
                listbx2.Items.Add(v);
            }
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Insert(0, tabPage5);
            lbl9.Text = listbx2.Items.Count.ToString();
            if (listbx2.Items.Count == 0)
            {
                btn12.Enabled = false;
                btn13.Enabled = false;
            }
            else
            {
                btn12.Enabled = true;
                btn13.Enabled = false;
            }
        }

        private void listbx2_SelectedIndexChanged(object sender, EventArgs e)
        {
            DirectoryInfo dd = new DirectoryInfo("E:\\siva\\oopsinsms\\sms\\" + txtbox1.Text + "\\sent\\" + listbx2.SelectedItem);
            foreach (FileInfo vv in dd.GetFiles())
            {
                string s = vv.Name;
                string[] dk = s.Split('.');
                listbx4.Items.Add(dk[0].ToString());
            }
        }

        private void listbx4_SelectedIndexChanged(object sender, EventArgs e)
        {
            richtxtbx2.Text = sms.fileRead("E:\\siva\\oopsinsms\\sms\\" + txtbox1.Text + "\\sent\\" + listbx2.SelectedItem + "\\" + listbx4.SelectedItem+".txt");
            if (richtxtbx2.Text != "")
            {
                btn13.Enabled = true;
            }
        }
        #endregion
        #region(Back process)
        private void btn11_Click(object sender, EventArgs e)
        {
            richtxtbx2.Clear();
            listbx2.Items.Clear();
            listbx4.Items.Clear();
            tabControl1.TabPages.Remove(tabPage5);
            tabControl1.TabPages.Insert(0, tabPage2);
        }

        private void btn8_Click(object sender, EventArgs e)
        {
            richtxtbx1.Clear();
            listbx3.Items.Clear();
            listbx1.Items.Clear();
            tabControl1.TabPages.Remove(tabPage3);
            tabControl1.TabPages.Insert(0, tabPage2);
        }

        private void btn16_Click(object sender, EventArgs e)
        {
            richtxtbx2.Clear();
            listbx2.Items.Clear();
            listbx4.Items.Clear();
            richtxtbx1.Clear();
            richtxtbx3.Clear();
            txtbox8.Clear();
            txtbox7.Clear();
            listbx1.Items.Clear();
            listbx3.Items.Clear();
            tabControl1.TabPages.Remove(tabPage4);
            tabControl1.TabPages.Insert(0, tabPage2);
        }
        private void btn7_Click(object sender, EventArgs e)
        {
                txtbox7.Text = listbx1.SelectedItem.ToString();
                tabControl1.TabPages.Remove(tabPage3);
                tabControl1.TabPages.Insert(0, tabPage4);
            

        }
        #endregion
        #region(DeleteProcess)
        private void btn12_Click(object sender, EventArgs e)
        {
            if (listbx2.Items.Count != 0)
            {
                if (listbx2.Text != "")
                {
                    DirectoryInfo dd = new DirectoryInfo("E:\\siva\\oopsinsms\\sms\\" + txtbox1.Text + "\\sent\\" + listbx2.SelectedItem);
                    foreach (FileInfo ddd in dd.GetFiles())
                    {
                        File.Delete("E:\\siva\\oopsinsms\\sms\\" + txtbox1.Text + "\\sent\\" + listbx2.SelectedItem + "\\" + ddd);
                        richtxtbx2.Clear();
                        listbx4.Items.Clear();
                    }
                    Directory.Delete("E:\\siva\\oopsinsms\\sms\\" + txtbox1.Text + "\\sent\\" + listbx2.SelectedItem);
                    listbx2.Items.Remove(listbx2.SelectedItem);
                    MessageBox.Show("Message Sucessfully Deleted");
                    lbl9.Text = listbx1.Items.Count.ToString();
                    if (listbx2.Items.Count == 0)
                    {
                        btn12.Enabled = false;
                        btn13.Enabled = false;
                    }
                }
                else
                {
                    MessageBox.Show("Select Sent Sms ");
                }
            }
            else
            {
                MessageBox.Show("No Message From Sent Items");
                btn12.Enabled = false;
                btn13.Enabled = false;
            }
        }

        private void btn6_Click(object sender, EventArgs e)
        {
            if (listbx1.Items.Count != 0)
            {
                if (listbx1.Text != "")
                {
                    DirectoryInfo dd = new DirectoryInfo("E:\\siva\\oopsinsms\\sms\\" + txtbox1.Text + "\\inbox\\" + listbx1.SelectedItem);
                    foreach (FileInfo ddd in dd.GetFiles())
                    {
                        File.Delete("E:\\siva\\oopsinsms\\sms\\" + txtbox1.Text + "\\inbox\\" + listbx1.SelectedItem + "\\"+ddd);
                        richtxtbx1.Clear();
                        listbx3.Items.Clear();
                    }
                    Directory.Delete("E:\\siva\\oopsinsms\\sms\\" + txtbox1.Text + "\\inbox\\" + listbx1.SelectedItem);
                    listbx1.Items.Remove(listbx1.SelectedItem);
                    MessageBox.Show("Message Sucessfully Deleted");
                    lbl8.Text = listbx1.Items.Count.ToString();
                    if (listbx1.Items.Count == 0)
                    {
                        btn6.Enabled = false;
                        btn7.Enabled = false;
                    }
                }
                else
                {
                    MessageBox.Show("Select Inbox ");
                }
            }
            else
            {
                MessageBox.Show("No Message From Inbox");
               
            }
        }
        #endregion
        #region(Forwardprocess)
        private void btn13_Click(object sender, EventArgs e)
        {
            if (richtxtbx2.Text != "")
            {
                txtbox8.Text = listbx4.SelectedItem.ToString();
                richtxtbx3.Text = richtxtbx2.Text;
                richtxtbx2.Clear();
                tabControl1.TabPages.Remove(tabPage5);
                tabControl1.TabPages.Insert(0, tabPage4);
            }
        }
        #endregion
        #region(LogoutProcess)
        private void btn10_Click(object sender, EventArgs e)
        {
            txtbox1.Clear();
            txtbox2.Clear();
            tabControl1.TabPages.Remove(tabPage5);
            tabControl1.TabPages.Insert(0, tabPage1);
        }

        private void btn9_Click(object sender, EventArgs e)
        {
            txtbox1.Clear();
            txtbox2.Clear();
            tabControl1.TabPages.Remove(tabPage3);
            tabControl1.TabPages.Insert(0, tabPage1);
        }

        private void btn17_Click(object sender, EventArgs e)
        {
            txtbox1.Clear();
            txtbox2.Clear();
            tabControl1.TabPages.Remove(tabPage4);
            tabControl1.TabPages.Insert(0, tabPage1);
        }
        private void btn5_Click(object sender, EventArgs e)
        {
            txtbox1.Clear();
            txtbox2.Clear();
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Insert(0, tabPage1);
        }
        #endregion
        #region(keyPerssCheck)
        private void txtbox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }
           
        }

        private void txtbox4_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (char.IsLetter(e.KeyChar))
            {
                e.Handled = true;
            }

        }
        #endregion

        private void btn20_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Remove(tabPage6);
            tabControl1.TabPages.Insert(0, tabPage1);

        }

        private void lbl25_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Remove(tabPage1);
            tabControl1.TabPages.Insert(0, tabPage6);
        }

    
    }
    #endregion
}  
    