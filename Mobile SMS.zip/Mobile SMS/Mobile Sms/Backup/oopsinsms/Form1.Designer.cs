﻿namespace oopsinsms
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tabControl1 = new System.Windows.Forms.TabControl();
            this.tabPage1 = new System.Windows.Forms.TabPage();
            this.lbl5 = new oopsinsms.lbl();
            this.lbl4 = new oopsinsms.lbl();
            this.lbl3 = new oopsinsms.lbl();
            this.txtbox2 = new oopsinsms.txtbox();
            this.lbl2 = new oopsinsms.lbl();
            this.txtbox1 = new oopsinsms.txtbox();
            this.lbl1 = new oopsinsms.lbl();
            this.btn1 = new oopsinsms.btn();
            this.tabPage2 = new System.Windows.Forms.TabPage();
            this.lbl6 = new oopsinsms.lbl();
            this.btn5 = new oopsinsms.btn();
            this.btn4 = new oopsinsms.btn();
            this.btn3 = new oopsinsms.btn();
            this.btn2 = new oopsinsms.btn();
            this.tabPage3 = new System.Windows.Forms.TabPage();
            this.lbl23 = new oopsinsms.lbl();
            this.lbl22 = new oopsinsms.lbl();
            this.listbx6 = new oopsinsms.listbx();
            this.listbx5 = new oopsinsms.listbx();
            this.btn19 = new oopsinsms.btn();
            this.btn18 = new oopsinsms.btn();
            this.lbl19 = new oopsinsms.lbl();
            this.listbx3 = new oopsinsms.listbx();
            this.lbl8 = new oopsinsms.lbl();
            this.lbl7 = new oopsinsms.lbl();
            this.btn9 = new oopsinsms.btn();
            this.btn8 = new oopsinsms.btn();
            this.btn7 = new oopsinsms.btn();
            this.btn6 = new oopsinsms.btn();
            this.richtxtbx1 = new oopsinsms.richtxtbx();
            this.listbx1 = new oopsinsms.listbx();
            this.tabPage4 = new System.Windows.Forms.TabPage();
            this.btn17 = new oopsinsms.btn();
            this.btn16 = new oopsinsms.btn();
            this.lbl18 = new oopsinsms.lbl();
            this.richtxtbx3 = new oopsinsms.richtxtbx();
            this.btn15 = new oopsinsms.btn();
            this.txtbox7 = new oopsinsms.txtbox();
            this.lbl16 = new oopsinsms.lbl();
            this.txtbox8 = new oopsinsms.txtbox();
            this.lbl17 = new oopsinsms.lbl();
            this.tabPage5 = new System.Windows.Forms.TabPage();
            this.lbl21 = new oopsinsms.lbl();
            this.lbl20 = new oopsinsms.lbl();
            this.listbx4 = new oopsinsms.listbx();
            this.richtxtbx2 = new oopsinsms.richtxtbx();
            this.lbl9 = new oopsinsms.lbl();
            this.btn10 = new oopsinsms.btn();
            this.lbl10 = new oopsinsms.lbl();
            this.btn11 = new oopsinsms.btn();
            this.listbx2 = new oopsinsms.listbx();
            this.btn13 = new oopsinsms.btn();
            this.btn12 = new oopsinsms.btn();
            this.tabPage6 = new System.Windows.Forms.TabPage();
            this.btn20 = new oopsinsms.btn();
            this.lbl24 = new oopsinsms.lbl();
            this.radiobtn2 = new oopsinsms.radiobtn();
            this.radiobtn1 = new oopsinsms.radiobtn();
            this.btn14 = new oopsinsms.btn();
            this.lbl15 = new oopsinsms.lbl();
            this.txtbox5 = new oopsinsms.txtbox();
            this.lbl13 = new oopsinsms.lbl();
            this.txtbox6 = new oopsinsms.txtbox();
            this.lbl14 = new oopsinsms.lbl();
            this.txtbox3 = new oopsinsms.txtbox();
            this.lbl11 = new oopsinsms.lbl();
            this.lbl12 = new oopsinsms.lbl();
            this.txtbox4 = new oopsinsms.txtbox();
            this.tabControl1.SuspendLayout();
            this.tabPage1.SuspendLayout();
            this.tabPage2.SuspendLayout();
            this.tabPage3.SuspendLayout();
            this.tabPage4.SuspendLayout();
            this.tabPage5.SuspendLayout();
            this.tabPage6.SuspendLayout();
            this.SuspendLayout();
            // 
            // tabControl1
            // 
            this.tabControl1.Controls.Add(this.tabPage1);
            this.tabControl1.Controls.Add(this.tabPage2);
            this.tabControl1.Controls.Add(this.tabPage3);
            this.tabControl1.Controls.Add(this.tabPage4);
            this.tabControl1.Controls.Add(this.tabPage5);
            this.tabControl1.Controls.Add(this.tabPage6);
            this.tabControl1.Location = new System.Drawing.Point(0, 0);
            this.tabControl1.Name = "tabControl1";
            this.tabControl1.SelectedIndex = 0;
            this.tabControl1.Size = new System.Drawing.Size(471, 404);
            this.tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            this.tabPage1.BackColor = System.Drawing.Color.Black;
            this.tabPage1.Controls.Add(this.lbl5);
            this.tabPage1.Controls.Add(this.lbl4);
            this.tabPage1.Controls.Add(this.lbl3);
            this.tabPage1.Controls.Add(this.txtbox2);
            this.tabPage1.Controls.Add(this.lbl2);
            this.tabPage1.Controls.Add(this.txtbox1);
            this.tabPage1.Controls.Add(this.lbl1);
            this.tabPage1.Controls.Add(this.btn1);
            this.tabPage1.Location = new System.Drawing.Point(4, 25);
            this.tabPage1.Name = "tabPage1";
            this.tabPage1.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage1.Size = new System.Drawing.Size(463, 375);
            this.tabPage1.TabIndex = 0;
            this.tabPage1.Text = "Login";
            // 
            // lbl5
            // 
            this.lbl5.AutoSize = true;
            this.lbl5.Font = new System.Drawing.Font("Modern No. 20", 12F, ((System.Drawing.FontStyle)(((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic)
                            | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl5.ForeColor = System.Drawing.Color.Yellow;
            this.lbl5.Location = new System.Drawing.Point(265, 273);
            this.lbl5.Name = "lbl5";
            this.lbl5.Size = new System.Drawing.Size(107, 22);
            this.lbl5.TabIndex = 7;
            this.lbl5.Text = "Click Here";
            this.lbl5.Click += new System.EventHandler(this.lbl5_Click);
            // 
            // lbl4
            // 
            this.lbl4.AutoSize = true;
            this.lbl4.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl4.ForeColor = System.Drawing.Color.Yellow;
            this.lbl4.Location = new System.Drawing.Point(8, 275);
            this.lbl4.Name = "lbl4";
            this.lbl4.Size = new System.Drawing.Size(251, 20);
            this.lbl4.TabIndex = 6;
            this.lbl4.Text = "Create An Account,If New User?";
            // 
            // lbl3
            // 
            this.lbl3.AutoSize = true;
            this.lbl3.Font = new System.Drawing.Font("Matura MT Script Capitals", 36F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl3.ForeColor = System.Drawing.Color.Fuchsia;
            this.lbl3.Location = new System.Drawing.Point(43, 19);
            this.lbl3.Name = "lbl3";
            this.lbl3.Size = new System.Drawing.Size(389, 79);
            this.lbl3.TabIndex = 5;
            this.lbl3.Text = "Mobile Sms";
            // 
            // txtbox2
            // 
            this.txtbox2.Location = new System.Drawing.Point(237, 151);
            this.txtbox2.Name = "txtbox2";
            this.txtbox2.Size = new System.Drawing.Size(135, 22);
            this.txtbox2.TabIndex = 4;
            this.txtbox2.UseSystemPasswordChar = true;
            // 
            // lbl2
            // 
            this.lbl2.AutoSize = true;
            this.lbl2.Font = new System.Drawing.Font("Magneto", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl2.ForeColor = System.Drawing.Color.Cyan;
            this.lbl2.Location = new System.Drawing.Point(84, 145);
            this.lbl2.Name = "lbl2";
            this.lbl2.Size = new System.Drawing.Size(147, 28);
            this.lbl2.TabIndex = 3;
            this.lbl2.Text = "Password:";
            // 
            // txtbox1
            // 
            this.txtbox1.Location = new System.Drawing.Point(237, 107);
            this.txtbox1.MaxLength = 10;
            this.txtbox1.Name = "txtbox1";
            this.txtbox1.Size = new System.Drawing.Size(135, 22);
            this.txtbox1.TabIndex = 2;
            this.txtbox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbox1_KeyPress);
            // 
            // lbl1
            // 
            this.lbl1.AutoSize = true;
            this.lbl1.Font = new System.Drawing.Font("Magneto", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl1.ForeColor = System.Drawing.Color.Cyan;
            this.lbl1.Location = new System.Drawing.Point(84, 98);
            this.lbl1.Name = "lbl1";
            this.lbl1.Size = new System.Drawing.Size(146, 28);
            this.lbl1.TabIndex = 1;
            this.lbl1.Text = "MobileNo:";
            // 
            // btn1
            // 
            this.btn1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(128)))));
            this.btn1.Font = new System.Drawing.Font("Magneto", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(0)))), ((int)(((byte)(192)))));
            this.btn1.Location = new System.Drawing.Point(200, 210);
            this.btn1.Name = "btn1";
            this.btn1.Size = new System.Drawing.Size(143, 37);
            this.btn1.TabIndex = 0;
            this.btn1.Text = "Login";
            this.btn1.UseVisualStyleBackColor = false;
            this.btn1.Click += new System.EventHandler(this.btn1_Click);
            // 
            // tabPage2
            // 
            this.tabPage2.BackColor = System.Drawing.Color.Black;
            this.tabPage2.Controls.Add(this.lbl6);
            this.tabPage2.Controls.Add(this.btn5);
            this.tabPage2.Controls.Add(this.btn4);
            this.tabPage2.Controls.Add(this.btn3);
            this.tabPage2.Controls.Add(this.btn2);
            this.tabPage2.Location = new System.Drawing.Point(4, 25);
            this.tabPage2.Name = "tabPage2";
            this.tabPage2.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage2.Size = new System.Drawing.Size(463, 375);
            this.tabPage2.TabIndex = 1;
            this.tabPage2.Text = "Way2Sms";
            // 
            // lbl6
            // 
            this.lbl6.AutoSize = true;
            this.lbl6.Font = new System.Drawing.Font("Magneto", 36F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl6.ForeColor = System.Drawing.Color.Lime;
            this.lbl6.Location = new System.Drawing.Point(26, 19);
            this.lbl6.Name = "lbl6";
            this.lbl6.Size = new System.Drawing.Size(424, 73);
            this.lbl6.TabIndex = 6;
            this.lbl6.Text = "Mobile Sms";
            // 
            // btn5
            // 
            this.btn5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn5.Font = new System.Drawing.Font("Magneto", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn5.ForeColor = System.Drawing.Color.Yellow;
            this.btn5.Location = new System.Drawing.Point(132, 277);
            this.btn5.Name = "btn5";
            this.btn5.Size = new System.Drawing.Size(199, 38);
            this.btn5.TabIndex = 4;
            this.btn5.Text = "Logout";
            this.btn5.UseVisualStyleBackColor = false;
            this.btn5.Click += new System.EventHandler(this.btn5_Click);
            // 
            // btn4
            // 
            this.btn4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn4.Font = new System.Drawing.Font("Magneto", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn4.ForeColor = System.Drawing.Color.Yellow;
            this.btn4.Location = new System.Drawing.Point(132, 222);
            this.btn4.Name = "btn4";
            this.btn4.Size = new System.Drawing.Size(199, 38);
            this.btn4.TabIndex = 3;
            this.btn4.Text = "Sent Sms";
            this.btn4.UseVisualStyleBackColor = false;
            this.btn4.Click += new System.EventHandler(this.btn4_Click);
            // 
            // btn3
            // 
            this.btn3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn3.Font = new System.Drawing.Font("Magneto", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn3.ForeColor = System.Drawing.Color.Yellow;
            this.btn3.Location = new System.Drawing.Point(132, 173);
            this.btn3.Name = "btn3";
            this.btn3.Size = new System.Drawing.Size(199, 38);
            this.btn3.TabIndex = 2;
            this.btn3.Text = "Inbox";
            this.btn3.UseVisualStyleBackColor = false;
            this.btn3.Click += new System.EventHandler(this.btn3_Click);
            // 
            // btn2
            // 
            this.btn2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.btn2.Font = new System.Drawing.Font("Magneto", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn2.ForeColor = System.Drawing.Color.Yellow;
            this.btn2.Location = new System.Drawing.Point(132, 124);
            this.btn2.Name = "btn2";
            this.btn2.Size = new System.Drawing.Size(199, 38);
            this.btn2.TabIndex = 1;
            this.btn2.Text = "New Sms";
            this.btn2.UseVisualStyleBackColor = false;
            this.btn2.Click += new System.EventHandler(this.btn2_Click);
            // 
            // tabPage3
            // 
            this.tabPage3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.tabPage3.Controls.Add(this.lbl23);
            this.tabPage3.Controls.Add(this.lbl22);
            this.tabPage3.Controls.Add(this.listbx6);
            this.tabPage3.Controls.Add(this.listbx5);
            this.tabPage3.Controls.Add(this.btn19);
            this.tabPage3.Controls.Add(this.btn18);
            this.tabPage3.Controls.Add(this.lbl19);
            this.tabPage3.Controls.Add(this.listbx3);
            this.tabPage3.Controls.Add(this.lbl8);
            this.tabPage3.Controls.Add(this.lbl7);
            this.tabPage3.Controls.Add(this.btn9);
            this.tabPage3.Controls.Add(this.btn8);
            this.tabPage3.Controls.Add(this.btn7);
            this.tabPage3.Controls.Add(this.btn6);
            this.tabPage3.Controls.Add(this.richtxtbx1);
            this.tabPage3.Controls.Add(this.listbx1);
            this.tabPage3.Location = new System.Drawing.Point(4, 25);
            this.tabPage3.Name = "tabPage3";
            this.tabPage3.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage3.Size = new System.Drawing.Size(463, 375);
            this.tabPage3.TabIndex = 2;
            this.tabPage3.Text = "Inbox";
            // 
            // lbl23
            // 
            this.lbl23.AutoSize = true;
            this.lbl23.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl23.ForeColor = System.Drawing.Color.Chartreuse;
            this.lbl23.Location = new System.Drawing.Point(214, 334);
            this.lbl23.Name = "lbl23";
            this.lbl23.Size = new System.Drawing.Size(97, 19);
            this.lbl23.TabIndex = 16;
            this.lbl23.Text = "UnReadSms";
            // 
            // lbl22
            // 
            this.lbl22.AutoSize = true;
            this.lbl22.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl22.ForeColor = System.Drawing.Color.Chartreuse;
            this.lbl22.Location = new System.Drawing.Point(3, 334);
            this.lbl22.Name = "lbl22";
            this.lbl22.Size = new System.Drawing.Size(76, 19);
            this.lbl22.TabIndex = 15;
            this.lbl22.Text = "ReadSms";
            // 
            // listbx6
            // 
            this.listbx6.BackColor = System.Drawing.Color.Black;
            this.listbx6.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listbx6.ForeColor = System.Drawing.Color.White;
            this.listbx6.FormattingEnabled = true;
            this.listbx6.ItemHeight = 18;
            this.listbx6.Location = new System.Drawing.Point(317, 333);
            this.listbx6.Name = "listbx6";
            this.listbx6.Size = new System.Drawing.Size(144, 22);
            this.listbx6.TabIndex = 14;
            // 
            // listbx5
            // 
            this.listbx5.BackColor = System.Drawing.Color.Black;
            this.listbx5.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listbx5.ForeColor = System.Drawing.Color.White;
            this.listbx5.FormattingEnabled = true;
            this.listbx5.ItemHeight = 18;
            this.listbx5.Location = new System.Drawing.Point(80, 334);
            this.listbx5.Name = "listbx5";
            this.listbx5.Size = new System.Drawing.Size(129, 22);
            this.listbx5.TabIndex = 13;
            // 
            // btn19
            // 
            this.btn19.BackColor = System.Drawing.Color.SaddleBrown;
            this.btn19.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn19.ForeColor = System.Drawing.Color.Yellow;
            this.btn19.Location = new System.Drawing.Point(390, 3);
            this.btn19.Name = "btn19";
            this.btn19.Size = new System.Drawing.Size(71, 27);
            this.btn19.TabIndex = 12;
            this.btn19.Text = "Unread";
            this.btn19.UseVisualStyleBackColor = false;
            // 
            // btn18
            // 
            this.btn18.BackColor = System.Drawing.Color.SaddleBrown;
            this.btn18.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn18.ForeColor = System.Drawing.Color.Yellow;
            this.btn18.Location = new System.Drawing.Point(317, 3);
            this.btn18.Name = "btn18";
            this.btn18.Size = new System.Drawing.Size(67, 27);
            this.btn18.TabIndex = 11;
            this.btn18.Text = "Read";
            this.btn18.UseVisualStyleBackColor = false;
            // 
            // lbl19
            // 
            this.lbl19.AutoSize = true;
            this.lbl19.Font = new System.Drawing.Font("Times New Roman", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl19.ForeColor = System.Drawing.Color.Chartreuse;
            this.lbl19.Location = new System.Drawing.Point(145, 45);
            this.lbl19.Name = "lbl19";
            this.lbl19.Size = new System.Drawing.Size(80, 19);
            this.lbl19.TabIndex = 10;
            this.lbl19.Text = "ClickSms";
            // 
            // listbx3
            // 
            this.listbx3.BackColor = System.Drawing.Color.Black;
            this.listbx3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listbx3.ForeColor = System.Drawing.Color.White;
            this.listbx3.FormattingEnabled = true;
            this.listbx3.ItemHeight = 18;
            this.listbx3.Location = new System.Drawing.Point(226, 44);
            this.listbx3.Name = "listbx3";
            this.listbx3.Size = new System.Drawing.Size(235, 22);
            this.listbx3.TabIndex = 9;
            this.listbx3.SelectedIndexChanged += new System.EventHandler(this.listbx3_SelectedIndexChanged);
            // 
            // lbl8
            // 
            this.lbl8.BackColor = System.Drawing.Color.Transparent;
            this.lbl8.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl8.ForeColor = System.Drawing.Color.Yellow;
            this.lbl8.Location = new System.Drawing.Point(51, 46);
            this.lbl8.Name = "lbl8";
            this.lbl8.Size = new System.Drawing.Size(45, 20);
            this.lbl8.TabIndex = 8;
            // 
            // lbl7
            // 
            this.lbl7.AutoSize = true;
            this.lbl7.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl7.ForeColor = System.Drawing.Color.Yellow;
            this.lbl7.Location = new System.Drawing.Point(6, 44);
            this.lbl7.Name = "lbl7";
            this.lbl7.Size = new System.Drawing.Size(48, 20);
            this.lbl7.TabIndex = 7;
            this.lbl7.Text = "Inbox";
            // 
            // btn9
            // 
            this.btn9.BackColor = System.Drawing.Color.SaddleBrown;
            this.btn9.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn9.ForeColor = System.Drawing.Color.Yellow;
            this.btn9.Location = new System.Drawing.Point(3, 3);
            this.btn9.Name = "btn9";
            this.btn9.Size = new System.Drawing.Size(71, 27);
            this.btn9.TabIndex = 5;
            this.btn9.Text = "Logout";
            this.btn9.UseVisualStyleBackColor = false;
            this.btn9.Click += new System.EventHandler(this.btn9_Click);
            // 
            // btn8
            // 
            this.btn8.BackColor = System.Drawing.Color.SaddleBrown;
            this.btn8.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn8.ForeColor = System.Drawing.Color.Yellow;
            this.btn8.Location = new System.Drawing.Point(80, 3);
            this.btn8.Name = "btn8";
            this.btn8.Size = new System.Drawing.Size(77, 27);
            this.btn8.TabIndex = 4;
            this.btn8.Text = "GoBack";
            this.btn8.UseVisualStyleBackColor = false;
            this.btn8.Click += new System.EventHandler(this.btn8_Click);
            // 
            // btn7
            // 
            this.btn7.BackColor = System.Drawing.Color.SaddleBrown;
            this.btn7.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn7.ForeColor = System.Drawing.Color.Yellow;
            this.btn7.Location = new System.Drawing.Point(163, 3);
            this.btn7.Name = "btn7";
            this.btn7.Size = new System.Drawing.Size(71, 27);
            this.btn7.TabIndex = 3;
            this.btn7.Text = "Reply";
            this.btn7.UseVisualStyleBackColor = false;
            this.btn7.Click += new System.EventHandler(this.btn7_Click);
            // 
            // btn6
            // 
            this.btn6.BackColor = System.Drawing.Color.SaddleBrown;
            this.btn6.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn6.ForeColor = System.Drawing.Color.Yellow;
            this.btn6.Location = new System.Drawing.Point(240, 3);
            this.btn6.Name = "btn6";
            this.btn6.Size = new System.Drawing.Size(71, 27);
            this.btn6.TabIndex = 2;
            this.btn6.Text = "Delete";
            this.btn6.UseVisualStyleBackColor = false;
            this.btn6.Click += new System.EventHandler(this.btn6_Click);
            // 
            // richtxtbx1
            // 
            this.richtxtbx1.BackColor = System.Drawing.Color.Black;
            this.richtxtbx1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richtxtbx1.ForeColor = System.Drawing.Color.White;
            this.richtxtbx1.Location = new System.Drawing.Point(149, 72);
            this.richtxtbx1.Name = "richtxtbx1";
            this.richtxtbx1.ReadOnly = true;
            this.richtxtbx1.Size = new System.Drawing.Size(312, 255);
            this.richtxtbx1.TabIndex = 1;
            this.richtxtbx1.Text = "";
            // 
            // listbx1
            // 
            this.listbx1.BackColor = System.Drawing.Color.Black;
            this.listbx1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listbx1.ForeColor = System.Drawing.Color.White;
            this.listbx1.FormattingEnabled = true;
            this.listbx1.ItemHeight = 18;
            this.listbx1.Location = new System.Drawing.Point(0, 72);
            this.listbx1.Name = "listbx1";
            this.listbx1.Size = new System.Drawing.Size(143, 256);
            this.listbx1.TabIndex = 0;
            this.listbx1.SelectedIndexChanged += new System.EventHandler(this.listbx1_SelectedIndexChanged);
            // 
            // tabPage4
            // 
            this.tabPage4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.tabPage4.Controls.Add(this.btn17);
            this.tabPage4.Controls.Add(this.btn16);
            this.tabPage4.Controls.Add(this.lbl18);
            this.tabPage4.Controls.Add(this.richtxtbx3);
            this.tabPage4.Controls.Add(this.btn15);
            this.tabPage4.Controls.Add(this.txtbox7);
            this.tabPage4.Controls.Add(this.lbl16);
            this.tabPage4.Controls.Add(this.txtbox8);
            this.tabPage4.Controls.Add(this.lbl17);
            this.tabPage4.Location = new System.Drawing.Point(4, 25);
            this.tabPage4.Name = "tabPage4";
            this.tabPage4.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage4.Size = new System.Drawing.Size(463, 375);
            this.tabPage4.TabIndex = 3;
            this.tabPage4.Text = "SendSms";
            // 
            // btn17
            // 
            this.btn17.BackColor = System.Drawing.Color.SaddleBrown;
            this.btn17.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn17.ForeColor = System.Drawing.Color.Yellow;
            this.btn17.Location = new System.Drawing.Point(317, -1);
            this.btn17.Name = "btn17";
            this.btn17.Size = new System.Drawing.Size(71, 27);
            this.btn17.TabIndex = 10;
            this.btn17.Text = "Logout";
            this.btn17.UseVisualStyleBackColor = false;
            this.btn17.Click += new System.EventHandler(this.btn17_Click);
            // 
            // btn16
            // 
            this.btn16.BackColor = System.Drawing.Color.SaddleBrown;
            this.btn16.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn16.ForeColor = System.Drawing.Color.Yellow;
            this.btn16.Location = new System.Drawing.Point(149, 0);
            this.btn16.Name = "btn16";
            this.btn16.Size = new System.Drawing.Size(89, 27);
            this.btn16.TabIndex = 11;
            this.btn16.Text = "Back";
            this.btn16.UseVisualStyleBackColor = false;
            this.btn16.Click += new System.EventHandler(this.btn16_Click);
            // 
            // lbl18
            // 
            this.lbl18.AutoSize = true;
            this.lbl18.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl18.ForeColor = System.Drawing.Color.Yellow;
            this.lbl18.Location = new System.Drawing.Point(1, 143);
            this.lbl18.Name = "lbl18";
            this.lbl18.Size = new System.Drawing.Size(82, 20);
            this.lbl18.TabIndex = 10;
            this.lbl18.Text = "Message:";
            // 
            // richtxtbx3
            // 
            this.richtxtbx3.BackColor = System.Drawing.Color.Black;
            this.richtxtbx3.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richtxtbx3.ForeColor = System.Drawing.Color.White;
            this.richtxtbx3.Location = new System.Drawing.Point(89, 143);
            this.richtxtbx3.Name = "richtxtbx3";
            this.richtxtbx3.Size = new System.Drawing.Size(295, 229);
            this.richtxtbx3.TabIndex = 2;
            this.richtxtbx3.Text = "";
            // 
            // btn15
            // 
            this.btn15.BackColor = System.Drawing.Color.SaddleBrown;
            this.btn15.Font = new System.Drawing.Font("Times New Roman", 7.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn15.ForeColor = System.Drawing.Color.Yellow;
            this.btn15.Location = new System.Drawing.Point(244, 0);
            this.btn15.Name = "btn15";
            this.btn15.Size = new System.Drawing.Size(67, 27);
            this.btn15.TabIndex = 5;
            this.btn15.Text = "Send";
            this.btn15.UseVisualStyleBackColor = false;
            this.btn15.Click += new System.EventHandler(this.btn15_Click);
            // 
            // txtbox7
            // 
            this.txtbox7.BackColor = System.Drawing.Color.Black;
            this.txtbox7.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbox7.ForeColor = System.Drawing.Color.White;
            this.txtbox7.Location = new System.Drawing.Point(89, 57);
            this.txtbox7.MaxLength = 10;
            this.txtbox7.Name = "txtbox7";
            this.txtbox7.Size = new System.Drawing.Size(295, 24);
            this.txtbox7.TabIndex = 9;
            // 
            // lbl16
            // 
            this.lbl16.AutoSize = true;
            this.lbl16.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl16.ForeColor = System.Drawing.Color.Yellow;
            this.lbl16.Location = new System.Drawing.Point(50, 57);
            this.lbl16.Name = "lbl16";
            this.lbl16.Size = new System.Drawing.Size(33, 20);
            this.lbl16.TabIndex = 8;
            this.lbl16.Text = "To:";
            // 
            // txtbox8
            // 
            this.txtbox8.BackColor = System.Drawing.Color.Black;
            this.txtbox8.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtbox8.ForeColor = System.Drawing.Color.White;
            this.txtbox8.Location = new System.Drawing.Point(89, 105);
            this.txtbox8.Name = "txtbox8";
            this.txtbox8.Size = new System.Drawing.Size(295, 24);
            this.txtbox8.TabIndex = 7;
            // 
            // lbl17
            // 
            this.lbl17.AutoSize = true;
            this.lbl17.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl17.ForeColor = System.Drawing.Color.Yellow;
            this.lbl17.Location = new System.Drawing.Point(40, 107);
            this.lbl17.Name = "lbl17";
            this.lbl17.Size = new System.Drawing.Size(43, 20);
            this.lbl17.TabIndex = 6;
            this.lbl17.Text = "Sub:";
            // 
            // tabPage5
            // 
            this.tabPage5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(0)))), ((int)(((byte)(64)))));
            this.tabPage5.Controls.Add(this.lbl21);
            this.tabPage5.Controls.Add(this.lbl20);
            this.tabPage5.Controls.Add(this.listbx4);
            this.tabPage5.Controls.Add(this.richtxtbx2);
            this.tabPage5.Controls.Add(this.lbl9);
            this.tabPage5.Controls.Add(this.btn10);
            this.tabPage5.Controls.Add(this.lbl10);
            this.tabPage5.Controls.Add(this.btn11);
            this.tabPage5.Controls.Add(this.listbx2);
            this.tabPage5.Controls.Add(this.btn13);
            this.tabPage5.Controls.Add(this.btn12);
            this.tabPage5.Location = new System.Drawing.Point(4, 25);
            this.tabPage5.Name = "tabPage5";
            this.tabPage5.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage5.Size = new System.Drawing.Size(463, 375);
            this.tabPage5.TabIndex = 4;
            this.tabPage5.Text = "SentSms";
            // 
            // lbl21
            // 
            this.lbl21.AutoSize = true;
            this.lbl21.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl21.ForeColor = System.Drawing.Color.Yellow;
            this.lbl21.Location = new System.Drawing.Point(96, 50);
            this.lbl21.Name = "lbl21";
            this.lbl21.Size = new System.Drawing.Size(0, 20);
            this.lbl21.TabIndex = 13;
            // 
            // lbl20
            // 
            this.lbl20.AutoSize = true;
            this.lbl20.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl20.ForeColor = System.Drawing.Color.Yellow;
            this.lbl20.Location = new System.Drawing.Point(150, 52);
            this.lbl20.Name = "lbl20";
            this.lbl20.Size = new System.Drawing.Size(80, 20);
            this.lbl20.TabIndex = 12;
            this.lbl20.Text = "ClickSms";
            // 
            // listbx4
            // 
            this.listbx4.BackColor = System.Drawing.Color.Black;
            this.listbx4.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listbx4.ForeColor = System.Drawing.Color.White;
            this.listbx4.FormattingEnabled = true;
            this.listbx4.ItemHeight = 18;
            this.listbx4.Location = new System.Drawing.Point(236, 50);
            this.listbx4.Name = "listbx4";
            this.listbx4.Size = new System.Drawing.Size(221, 22);
            this.listbx4.TabIndex = 10;
            this.listbx4.SelectedIndexChanged += new System.EventHandler(this.listbx4_SelectedIndexChanged);
            // 
            // richtxtbx2
            // 
            this.richtxtbx2.BackColor = System.Drawing.Color.Black;
            this.richtxtbx2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.richtxtbx2.ForeColor = System.Drawing.Color.White;
            this.richtxtbx2.Location = new System.Drawing.Point(139, 83);
            this.richtxtbx2.Name = "richtxtbx2";
            this.richtxtbx2.ReadOnly = true;
            this.richtxtbx2.Size = new System.Drawing.Size(318, 292);
            this.richtxtbx2.TabIndex = 2;
            this.richtxtbx2.Text = "";
            // 
            // lbl9
            // 
            this.lbl9.AutoSize = true;
            this.lbl9.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl9.ForeColor = System.Drawing.Color.Yellow;
            this.lbl9.Location = new System.Drawing.Point(90, 50);
            this.lbl9.Name = "lbl9";
            this.lbl9.Size = new System.Drawing.Size(0, 20);
            this.lbl9.TabIndex = 11;
            // 
            // btn10
            // 
            this.btn10.BackColor = System.Drawing.Color.SaddleBrown;
            this.btn10.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn10.ForeColor = System.Drawing.Color.Yellow;
            this.btn10.Location = new System.Drawing.Point(382, 6);
            this.btn10.Name = "btn10";
            this.btn10.Size = new System.Drawing.Size(71, 27);
            this.btn10.TabIndex = 9;
            this.btn10.Text = "Logout";
            this.btn10.UseVisualStyleBackColor = false;
            this.btn10.Click += new System.EventHandler(this.btn10_Click);
            // 
            // lbl10
            // 
            this.lbl10.AutoSize = true;
            this.lbl10.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl10.ForeColor = System.Drawing.Color.Yellow;
            this.lbl10.Location = new System.Drawing.Point(6, 50);
            this.lbl10.Name = "lbl10";
            this.lbl10.Size = new System.Drawing.Size(77, 20);
            this.lbl10.TabIndex = 10;
            this.lbl10.Text = "SentSms";
            // 
            // btn11
            // 
            this.btn11.BackColor = System.Drawing.Color.SaddleBrown;
            this.btn11.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn11.ForeColor = System.Drawing.Color.Yellow;
            this.btn11.Location = new System.Drawing.Point(299, 6);
            this.btn11.Name = "btn11";
            this.btn11.Size = new System.Drawing.Size(77, 27);
            this.btn11.TabIndex = 8;
            this.btn11.Text = "GoBack";
            this.btn11.UseVisualStyleBackColor = false;
            this.btn11.Click += new System.EventHandler(this.btn11_Click);
            // 
            // listbx2
            // 
            this.listbx2.BackColor = System.Drawing.Color.Black;
            this.listbx2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listbx2.ForeColor = System.Drawing.Color.White;
            this.listbx2.FormattingEnabled = true;
            this.listbx2.ItemHeight = 18;
            this.listbx2.Location = new System.Drawing.Point(-4, 83);
            this.listbx2.Name = "listbx2";
            this.listbx2.Size = new System.Drawing.Size(143, 292);
            this.listbx2.TabIndex = 9;
            this.listbx2.SelectedIndexChanged += new System.EventHandler(this.listbx2_SelectedIndexChanged);
            // 
            // btn13
            // 
            this.btn13.BackColor = System.Drawing.Color.SaddleBrown;
            this.btn13.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn13.ForeColor = System.Drawing.Color.Yellow;
            this.btn13.Location = new System.Drawing.Point(145, 6);
            this.btn13.Name = "btn13";
            this.btn13.Size = new System.Drawing.Size(71, 27);
            this.btn13.TabIndex = 6;
            this.btn13.Text = "Forward";
            this.btn13.UseVisualStyleBackColor = false;
            this.btn13.Click += new System.EventHandler(this.btn13_Click);
            // 
            // btn12
            // 
            this.btn12.BackColor = System.Drawing.Color.SaddleBrown;
            this.btn12.Font = new System.Drawing.Font("Times New Roman", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn12.ForeColor = System.Drawing.Color.Yellow;
            this.btn12.Location = new System.Drawing.Point(222, 6);
            this.btn12.Name = "btn12";
            this.btn12.Size = new System.Drawing.Size(71, 27);
            this.btn12.TabIndex = 7;
            this.btn12.Text = "Delete";
            this.btn12.UseVisualStyleBackColor = false;
            this.btn12.Click += new System.EventHandler(this.btn12_Click);
            // 
            // tabPage6
            // 
            this.tabPage6.BackColor = System.Drawing.Color.Black;
            this.tabPage6.Controls.Add(this.btn20);
            this.tabPage6.Controls.Add(this.lbl24);
            this.tabPage6.Controls.Add(this.radiobtn2);
            this.tabPage6.Controls.Add(this.radiobtn1);
            this.tabPage6.Controls.Add(this.btn14);
            this.tabPage6.Controls.Add(this.lbl15);
            this.tabPage6.Controls.Add(this.txtbox5);
            this.tabPage6.Controls.Add(this.lbl13);
            this.tabPage6.Controls.Add(this.txtbox6);
            this.tabPage6.Controls.Add(this.lbl14);
            this.tabPage6.Controls.Add(this.txtbox3);
            this.tabPage6.Controls.Add(this.lbl11);
            this.tabPage6.Controls.Add(this.lbl12);
            this.tabPage6.Controls.Add(this.txtbox4);
            this.tabPage6.Location = new System.Drawing.Point(4, 25);
            this.tabPage6.Name = "tabPage6";
            this.tabPage6.Padding = new System.Windows.Forms.Padding(3);
            this.tabPage6.Size = new System.Drawing.Size(463, 375);
            this.tabPage6.TabIndex = 5;
            this.tabPage6.Text = "Registration";
            // 
            // btn20
            // 
            this.btn20.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn20.Font = new System.Drawing.Font("Magneto", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn20.ForeColor = System.Drawing.Color.Fuchsia;
            this.btn20.Location = new System.Drawing.Point(153, 336);
            this.btn20.Name = "btn20";
            this.btn20.Size = new System.Drawing.Size(168, 27);
            this.btn20.TabIndex = 16;
            this.btn20.Text = "Back To Login";
            this.btn20.UseVisualStyleBackColor = false;
            this.btn20.Click += new System.EventHandler(this.btn20_Click);
            // 
            // lbl24
            // 
            this.lbl24.AutoSize = true;
            this.lbl24.Font = new System.Drawing.Font("Magneto", 25.8F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Italic))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl24.ForeColor = System.Drawing.Color.Yellow;
            this.lbl24.Location = new System.Drawing.Point(96, 3);
            this.lbl24.Name = "lbl24";
            this.lbl24.Size = new System.Drawing.Size(259, 52);
            this.lbl24.TabIndex = 7;
            this.lbl24.Text = "Way2Sms";
            // 
            // radiobtn2
            // 
            this.radiobtn2.AutoSize = true;
            this.radiobtn2.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiobtn2.ForeColor = System.Drawing.Color.White;
            this.radiobtn2.Location = new System.Drawing.Point(272, 120);
            this.radiobtn2.Name = "radiobtn2";
            this.radiobtn2.Size = new System.Drawing.Size(84, 22);
            this.radiobtn2.TabIndex = 15;
            this.radiobtn2.TabStop = true;
            this.radiobtn2.Text = "Female";
            this.radiobtn2.UseVisualStyleBackColor = true;
            // 
            // radiobtn1
            // 
            this.radiobtn1.AutoSize = true;
            this.radiobtn1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.radiobtn1.ForeColor = System.Drawing.Color.White;
            this.radiobtn1.Location = new System.Drawing.Point(209, 120);
            this.radiobtn1.Name = "radiobtn1";
            this.radiobtn1.Size = new System.Drawing.Size(65, 22);
            this.radiobtn1.TabIndex = 14;
            this.radiobtn1.TabStop = true;
            this.radiobtn1.Text = "Male";
            this.radiobtn1.UseVisualStyleBackColor = true;
            // 
            // btn14
            // 
            this.btn14.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(192)))), ((int)(((byte)(255)))));
            this.btn14.Font = new System.Drawing.Font("Magneto", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn14.ForeColor = System.Drawing.Color.DarkGreen;
            this.btn14.Location = new System.Drawing.Point(132, 297);
            this.btn14.Name = "btn14";
            this.btn14.Size = new System.Drawing.Size(204, 27);
            this.btn14.TabIndex = 2;
            this.btn14.Text = "Registration";
            this.btn14.UseVisualStyleBackColor = false;
            this.btn14.Click += new System.EventHandler(this.btn14_Click);
            // 
            // lbl15
            // 
            this.lbl15.AutoSize = true;
            this.lbl15.Font = new System.Drawing.Font("Magneto", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl15.ForeColor = System.Drawing.Color.Cyan;
            this.lbl15.Location = new System.Drawing.Point(67, 240);
            this.lbl15.Name = "lbl15";
            this.lbl15.Size = new System.Drawing.Size(136, 28);
            this.lbl15.TabIndex = 13;
            this.lbl15.Text = "Address:";
            // 
            // txtbox5
            // 
            this.txtbox5.Location = new System.Drawing.Point(209, 202);
            this.txtbox5.Name = "txtbox5";
            this.txtbox5.Size = new System.Drawing.Size(137, 22);
            this.txtbox5.TabIndex = 12;
            this.txtbox5.UseSystemPasswordChar = true;
            // 
            // lbl13
            // 
            this.lbl13.AutoSize = true;
            this.lbl13.Font = new System.Drawing.Font("Magneto", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl13.ForeColor = System.Drawing.Color.Cyan;
            this.lbl13.Location = new System.Drawing.Point(57, 156);
            this.lbl13.Name = "lbl13";
            this.lbl13.Size = new System.Drawing.Size(146, 28);
            this.lbl13.TabIndex = 11;
            this.lbl13.Text = "MobileNo:";
            // 
            // txtbox6
            // 
            this.txtbox6.Location = new System.Drawing.Point(209, 246);
            this.txtbox6.Name = "txtbox6";
            this.txtbox6.Size = new System.Drawing.Size(137, 22);
            this.txtbox6.TabIndex = 10;
            // 
            // lbl14
            // 
            this.lbl14.AutoSize = true;
            this.lbl14.Font = new System.Drawing.Font("Magneto", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl14.ForeColor = System.Drawing.Color.Cyan;
            this.lbl14.Location = new System.Drawing.Point(56, 197);
            this.lbl14.Name = "lbl14";
            this.lbl14.Size = new System.Drawing.Size(147, 28);
            this.lbl14.TabIndex = 9;
            this.lbl14.Text = "Password:";
            // 
            // txtbox3
            // 
            this.txtbox3.Location = new System.Drawing.Point(209, 74);
            this.txtbox3.Name = "txtbox3";
            this.txtbox3.Size = new System.Drawing.Size(137, 22);
            this.txtbox3.TabIndex = 8;
            // 
            // lbl11
            // 
            this.lbl11.AutoSize = true;
            this.lbl11.Font = new System.Drawing.Font("Magneto", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl11.ForeColor = System.Drawing.Color.Cyan;
            this.lbl11.Location = new System.Drawing.Point(44, 68);
            this.lbl11.Name = "lbl11";
            this.lbl11.Size = new System.Drawing.Size(159, 28);
            this.lbl11.TabIndex = 7;
            this.lbl11.Text = "UserName:";
            // 
            // lbl12
            // 
            this.lbl12.AutoSize = true;
            this.lbl12.Font = new System.Drawing.Font("Magneto", 13.8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl12.ForeColor = System.Drawing.Color.Cyan;
            this.lbl12.Location = new System.Drawing.Point(85, 113);
            this.lbl12.Name = "lbl12";
            this.lbl12.Size = new System.Drawing.Size(118, 28);
            this.lbl12.TabIndex = 5;
            this.lbl12.Text = "Gender:";
            // 
            // txtbox4
            // 
            this.txtbox4.Location = new System.Drawing.Point(209, 162);
            this.txtbox4.MaxLength = 10;
            this.txtbox4.Name = "txtbox4";
            this.txtbox4.Size = new System.Drawing.Size(137, 22);
            this.txtbox4.TabIndex = 6;
            this.txtbox4.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtbox4_KeyPress);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(466, 400);
            this.Controls.Add(this.tabControl1);
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Form1";
            this.Text = "Way2Sms";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.tabControl1.ResumeLayout(false);
            this.tabPage1.ResumeLayout(false);
            this.tabPage1.PerformLayout();
            this.tabPage2.ResumeLayout(false);
            this.tabPage2.PerformLayout();
            this.tabPage3.ResumeLayout(false);
            this.tabPage3.PerformLayout();
            this.tabPage4.ResumeLayout(false);
            this.tabPage4.PerformLayout();
            this.tabPage5.ResumeLayout(false);
            this.tabPage5.PerformLayout();
            this.tabPage6.ResumeLayout(false);
            this.tabPage6.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.TabControl tabControl1;
        private System.Windows.Forms.TabPage tabPage1;
        private System.Windows.Forms.TabPage tabPage2;
        private System.Windows.Forms.TabPage tabPage3;
        private System.Windows.Forms.TabPage tabPage4;
        private System.Windows.Forms.TabPage tabPage5;
        private System.Windows.Forms.TabPage tabPage6;
        private txtbox txtbox1;
        private lbl lbl1;
        private btn btn1;
        private txtbox txtbox2;
        private lbl lbl2;
        private lbl lbl5;
        private lbl lbl4;
        private lbl lbl3;
        private btn btn5;
        private btn btn4;
        private btn btn3;
        private btn btn2;
        private lbl lbl6;
        private richtxtbx richtxtbx1;
        private listbx listbx1;
        private btn btn9;
        private btn btn8;
        private btn btn7;
        private btn btn6;
        private lbl lbl8;
        private lbl lbl7;
        private richtxtbx richtxtbx2;
        private lbl lbl9;
        private btn btn10;
        private lbl lbl10;
        private btn btn11;
        private listbx listbx2;
        private btn btn13;
        private btn btn12;
        private txtbox txtbox5;
        private lbl lbl13;
        private txtbox txtbox6;
        private lbl lbl14;
        private txtbox txtbox3;
        private lbl lbl11;
        private lbl lbl12;
        private txtbox txtbox4;
        private btn btn14;
        private lbl lbl15;
        private radiobtn radiobtn2;
        private radiobtn radiobtn1;
        private lbl lbl18;
        private richtxtbx richtxtbx3;
        private btn btn15;
        private txtbox txtbox7;
        private lbl lbl16;
        private txtbox txtbox8;
        private lbl lbl17;
        private listbx listbx3;
        private lbl lbl19;
        private lbl lbl20;
        private listbx listbx4;
        private btn btn16;
        private lbl lbl21;
        private btn btn17;
        private listbx listbx5;
        private btn btn19;
        private btn btn18;
        private lbl lbl23;
        private lbl lbl22;
        private listbx listbx6;
        private lbl lbl24;
        private btn btn20;
    }
}

