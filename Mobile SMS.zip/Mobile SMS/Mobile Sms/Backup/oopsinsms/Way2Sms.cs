﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Windows.Forms;
namespace oopsinsms
{

   
      #region("Customecontrols")
        class txtbox:TextBox
       {
        }
      class lbl:Label
       {
        }
     class btn:Button
       {
       }
     class listbx :ListBox
     {
     }
     class richtxtbx : RichTextBox
     {
     }
     class radiobtn : RadioButton
     {
     }
  #endregion
     
     class sms
     {
         #region("FileCreate")
         public void filewrite(string path,string uname,string gender,string mob,string passwd,string add)
    {
         string d=uname+" \n "+gender+" "+mob+" "+passwd+" "+add;
         TextWriter a;
         a=File.CreateText(path);
         a.WriteLine(d);
         a.Flush();
         a.Close();

    }
         public void filewrite(string path, string msg)
         {
             string d = msg;
             TextWriter a;
             a = File.CreateText(path);
             a.WriteLine(d);
             a.Flush();
             a.Close();

         }
         #endregion
         #region("FileRead")
         public string  fileRead(string path)
         {
            string d=System.IO.File.ReadAllText(path);
            return d;
          }
         #endregion
       

     }
   
     
 }
