/**
 * Created with IntelliJ IDEA.
 * User: ivan.kozhuharov
 * Date: 9/9/13
 * Time: 2:16 PM
 * To change this template use File | Settings | File Templates.
 */
var updjs = {};
(function () {
	var cxi = cxi || {
		dws:function (a) { document.write('<scr' + 'ipt type="text/javascript" src="' + a + '"></scr' + 'ipt>'); },
		dwi:function (a) { document.write('<img style="display: none" src="' + a + '">'); }
	};

	var cT = {
		trid: 5269326,
		rouv: {id:[2736082, 2736082], src:['http://servedby.adsdumpo.com/ttj', 'http://servedby.adsdumpo.com/ttj' ]},
		sU:   {ip:['http://trstream.adsplats.com','http://trstream.adsplats.com', 'http://trstream.adsplats.com'], pth:['/wl/', '/wl/', '/wl/'], prcnt:[33, 33, 34]},
		px:   '5269326.gif',
		wlU:'../../v161/wl.js',
		v:    161,
		imps: 0,
		ftdsb:['DE.init'],
		inU:  location.href
};


var DE = function (__tag) {
	this._ts = null;
	this._tag = __tag;
	this._tag.tDm = null;
	this._tag.size = null;
	this._tag.rU = null;
	this._tag.rid = null;
	this._res = {};
};

DE.prototype = {

	init:function () {
		this._ts = new Date().getTime();
		this._tag.tDm = gTpL();
		this._tag.size = gParNa('size', this._tag.inU);
		this._tag.rU = gParNa('referrer', this._tag.inU);
		this._tag.rid = guid();

		this._res.ts = this._ts;
		this._res.trid = this._tag.trid;
		this._res.v = this._tag.v;
		this._res.rid = this._tag.rid;
		this._res.orRU = this._tag.rU;
		this.mngR();
	},

	goSt:function (index, dws) {
		var sU = this._tag.rouv.src[index] + '?id=' + this._tag.rouv.id[index] + '&' + gQS(this._tag.inU);
		dws(sU);
		this._tag.imps = 1;
		this._res.sntU = sU + '&_e';
	},

	goLg:function (index, dwi) {
		this._res.pid = this._tag.rouv.id[index].toString();
		this._res.tpU = this._tag.tDm + '&_e';

		if (this._tag.rU != null)
			this._res.rU = this._tag.rU;

		dwi(this._tag.px + '?' + decodeURIComponent(oUPar(this._res)));
	},

	goCm:function (index, dwi) {
		dwi('http://b.scorecardresearch.com/p?c1=8&c2=6035951&c3=' + this._tag.rouv.id[index] + '&c4=&c5=&c6=&c15=&cv=2.0&cj=20');
	},

	mngR:function () {
		var inU = this._tag.inU;

		if (inU.indexOf('&referrer=') == -1) {
			inU += '&referrer=' + gHNa(this._tag.tDm);
			this._tag.rU = gHNa(this._tag.tDm);
		}
		else if (isParNoE(this._tag.rU) || !isAN(this._tag.rU.charCodeAt(0))) {
			inU = inU.replace('&referrer=' + this._tag.rU, '&referrer=' + gHNa(this._tag.tDm));
			this._tag.rU = gHNa(this._tag.tDm);
		}

		this._tag.inU = inU;
	}
};

function jsLR() {
	var _dec = new DE(cT);
	_dec.init();

	try{
		jsLsr(gRnSU(cT.sU) + _dec._tag.rU.replace('http://', '').replace('https://', ''));
	}catch(er0){
		_dec = null;
		return false;
	}

	if(iw == null) {
		_dec = null;
		return false;
	}

	_dec._res.swl = 1;

	if (iw == true) {
		_dec._res.iWL = 1;
		_dec.goSt(1, cxi.dws);
		_dec.goLg(1, cxi.dwi);
		_dec.goCm(1, cxi.dwi);

	} else {
		_dec._res.iWL = 0;
		_dec.goSt(0, cxi.dws);
		_dec.goLg(0, cxi.dwi);
		_dec.goCm(0, cxi.dwi);
	}
	return true;
}

updjs.iwl = function(){
	var _dec = new DE(cT);
	_dec.init();

	var iws =  WLS.getInstance();
	var iw = iws.checkWord(_dec._tag.rU.replace('http://', '').replace('https://', ''));

	_dec._res.swl = 0;
	if (iw) {
		_dec._res.iWL = 1;
		_dec.goSt(1, cxi.dws);
		_dec.goLg(1, cxi.dwi);
		_dec.goCm(1, cxi.dwi);

	} else {
		_dec._res.iWL = 0;
		_dec.goSt(0, cxi.dws);
		_dec.goLg(0, cxi.dwi);
		_dec.goCm(0, cxi.dwi);
	}
	return ;
}

function init() {
	try {
		if(!jsLR())
			cxi.dws(cT.wlU);
	} catch (err) {
		var s = cT.rouv.src[0] + '?id=' + cT.rouv.id[0] + '&size=' + gParNa('size', cT.inU);
		if (!cT.imps)
			cxi.dws(s);

		cxi.dwi(cT.px + '?er=1' + '&erd=' + err.name + ':' + err.message + '?id=' + cT.rouv.id[0]);
	}
}
///// tools
function jsLsr(inFN)
{
	var aReq,aSSo;
	if(window.XDomainRequest) {aReq = new XDomainRequest();}
	else if (window.XMLHttpRequest) {aReq = new XMLHttpRequest(); }
	else { aReq = new ActiveXObject("Microsoft.XMLHTTP"); }
	aReq.open('GET', inFN, false);
	aReq.send();

	aSSo = aReq.responseText + '\n////# sourceURL=' + inFN + '\n';
	eval(aSSo);
}

function oUPar(obj) {
	var pr = [];
	for (var key in obj)
		if (obj.hasOwnProperty(key))
			pr.push(encodeURIComponent(key) + '=' + encodeURIComponent(obj[key]));

	return  pr.join('&');
}

function iSConWAr(strTL, arr) {
	for (var i = 0, len = arr.length; i < len; ++i)
		if (strTL.indexOf(arr[i]) != -1)
			return true;

	return false;
}

function gParNa(n, url) {
	n = n.replace(/[\[]/, "\\\[").replace(/[\]]/, "\\\]");
	var rg = "[\\?&]" + n + "=([^&#]*)";
	var rx = new RegExp(rg);
	var rr = rx.exec(url);
	if (rr == null)
		return null;
	else
		return rr[1];
}

function gHNa(sU) {
	var sI = sU.indexOf('http');
	var i1d = sU.indexOf('.');

	if (sI == -1)             sU = 'http://' + sU;
	else if (sI > i1d)        sU = 'http://' + sU;

	var i3sl = sU.indexOf("/", 9);
	var indEnd = i3sl;
	var ind1Q = sU.indexOf('?', 9);

	if (ind1Q == i3sl)    return sU;
	if (i3sl == -1 && ind1Q > 0) indEnd = ind1Q;
	if (ind1Q > 0 && i3sl > 0)    indEnd = ind1Q < i3sl ? ind1Q : i3sl;

	return  sU.substring(0, indEnd);
}

function gQS(su) {
	var ind1Q = su.indexOf('?', 0);

	if (ind1Q > -1)
		return su.substring(ind1Q + 1, su.length);

	return null;
}

function gTpL() {
	var dp = 0, w = window, U = null;

	try {
		U = window.top.location.href;
	} catch (err) {
		U = null;
	}

	try {
		if (U == null) {
			for (; w !== window.top; w = w.parent, ++dp);
			U = w.location.href;
		}
	} catch (err) {
		U = null;
	}

	try {
		if (U == null)  U = window.document.referrer;
	} catch (err) {
		U = null;
	}

	if (U == null)    U = window.document.location.href;

	return U;
}

function guid() {
	function _p8(s) {
		var p = (Math.random().toString(16) + "000000000").substr(2, 8);
		return s ? "-" + p.substr(0, 4) + "-" + p.substr(4, 4) : p;
	}

	return _p8() + _p8(true) + _p8(true) + _p8();
}

function isAN(cc) {
	if ((cc > 47 && cc < 58) || (cc > 64 && cc < 91) || (cc > 96 && cc < 123)) return true;
	return false;
}

function isParNoE(el) {
	if (el === "" || el === 0 || el === "0" || el === null || el === "null" || el === "NULL" || el === undefined || el === false) {
		return true;
	}
	if (typeof(el) === 'object') {
		var i = 0;
		for (key in el) {
			i++;
		}
		if (i === 0) {
			return true;
		}
	}
	return false;
}

function gRnSU(ar) {
	var i = Math.floor(Math.random() * (ar.ip.length));
	return ar.ip[i] + ar.pth[i];
}

init();
//	function gRnSU(ar) {
//		var c= 0, n = Math.floor(Math.random() * 100 );// (ar.ip.length));
//		for(var pr in ar.prcnt)
//			if( pr <= n ){
//				return ar.ip[c] + ar.pth[c];
//			}
//	}

}());














