﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Data;
using System.Drawing;
using System.Windows.Forms;
namespace flipkart
{
    interface Interface1
    {
       //string autostr(string name);
        string fileread(string path);
        void filewrite(string path,string[] content);
        string filedelete(string path);
        void img(string path);
        DataTable datagrid(string path);
        DataTable filedrd(string path);
        DataTable fimg(string path);
        DataTable fcsh(string path);
       // Image pimg(string path);
    }
}
