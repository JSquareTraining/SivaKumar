﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Drawing;
using System.IO;
using System.Data;
using System.Windows.Forms;
namespace flipkart
{
    class flip : Interface1
    {
        string j;
        //string kk;
        public string fileread(string path)
        {
            j = "";
            DirectoryInfo d = new DirectoryInfo(path);
            foreach (DirectoryInfo item in d.GetDirectories())
            {

                j += item + ",".ToString();
                //string[] cf = j.Split('.');
                //j = cf[0];
                //kk += j + ",";               

            }

            return j;
        }
        public void filewrite(string path, params string[] content)
        {
            string[] k = content;
            TextWriter d = System.IO.File.CreateText(path);
            d.WriteLine(k[0] + "|" + k[1] + "|" + k[2] + "|" + k[3] + "|" + k[4] + "|" + k[5]+"|"+0);
            d.Flush();
            d.Close();
        }

        public string filedelete(string path)
        {
            throw new NotImplementedException();
        }

        public void img(string path)
        {
        }
        string dd;
        string h;
        int z,y=1, zz = 0;
        public DataTable datagrid(string path)
        {
            zz = 0;
            h = "";
            DataTable dt = new DataTable();
            DirectoryInfo d = new DirectoryInfo(path);
            foreach (DirectoryInfo item in d.GetDirectories())
            {

                h += item + ",".ToString();

            }
            string[] hh = h.Split(',');
            z = hh.Count() - 1;
            for (int i = 0; i < z; i++)
            {
                if (zz == 0)
                {
                    dt.Columns.Add("No", typeof(int));
                    dt.Columns.Add("Product Company", typeof(string));
                    dt.Columns.Add("Details", typeof(string));
                    zz++;
                }
                dt.Rows.Add(y,hh[i], "View Details");
                y += 1;

            }
            y = 1;
            return dt;
          

        }
        int x = 1;
        public DataTable filedrd(string path)
        {
            zz = 0;
            h = "";
           
            DataTable ddt = new DataTable();
            DirectoryInfo dd = new DirectoryInfo(path);
            foreach (FileInfo item in dd.GetFiles())
            {
                string xd = item.ToString();
                string[] cc = xd.Split('.');
                h += cc[0] + ",".ToString();
            }
            string[] hh = h.Split(',');
            z = hh.Count() - 1;
            for (int i = 0; i < z; i++)
            {
               
                string dl = System.IO.File.ReadAllText(path+"\\"+hh[i]+".txt");
                string[] d = dl.Split('|');
                if (o == 0)
                {
                    ddt.Columns.Add("No", typeof(int));
                    ddt.Columns.Add("Product", typeof(string));
                    ddt.Columns.Add("Product Brand", typeof(string));
                    ddt.Columns.Add("Product Model", typeof(string));
                    ddt.Columns.Add("Stock", typeof(string));
                    ddt.Columns.Add("Price", typeof(string));
                    ddt.Columns.Add("Product Image", typeof(Image));
                    ddt.Columns.Add("Order", typeof(string));
                    zz++;
                    o += 1;
                }
                //if (d[3] == "0")
                //{
                //    d[3] = "No Stock";
                //}

                ddt.Rows.Add(x,d[0], d[1], d[2], d[3], d[4], Image.FromFile(d[5]), "Click Here");

                x += 1;



              
               // return dt;

            }

            x = 1;

            o = 0;
            return ddt;
           
        }




        int o = 0;
        public DataTable fimg(string path)
        {



            zz = 0;
            h = "";

            DataTable ddt = new DataTable();
            DirectoryInfo dd = new DirectoryInfo(path);
            foreach (FileInfo item in dd.GetFiles())
            {
                string xd = item.ToString();
                string[] cc = xd.Split('.');
                h += cc[0] + ",".ToString();
            }
            string[] hh = h.Split(',');
            z = hh.Count() - 1;
            for (int i = 0; i < z; i++)
            {

                string dl = System.IO.File.ReadAllText(path + "\\" + hh[i] + ".txt");
                string[] d = dl.Split('|');
                if (o == 0)
                {
                    ddt.Columns.Add("No", typeof(int));
                    ddt.Columns.Add("Name", typeof(string));
                    ddt.Columns.Add("Phone Number", typeof(string));
                    ddt.Columns.Add("Address", typeof(string));
                    ddt.Columns.Add("Pincode", typeof(string));
                    ddt.Columns.Add("Amount", typeof(string));
                    ddt.Columns.Add("Order Date", typeof(string));
                    ddt.Columns.Add("Payment mode", typeof(string));
                    zz++;
                    o += 1;
                }
                ddt.Rows.Add(x, d[0], d[1], d[2], d[3], d[4], d[5], "Cash on delivery");

                x += 1;             

            }

            x = 1;

            o = 0;
            return ddt;

        }





        
        public DataTable fcsh(string path)
        {
            zz = 0;
            h = "";

            DataTable ddt = new DataTable();
            DirectoryInfo dd = new DirectoryInfo(path);
            foreach (FileInfo item in dd.GetFiles())
            {
                string xd = item.ToString();
                string[] cc = xd.Split('.');
                h += cc[0] + ",".ToString();
            }
            string[] hh = h.Split(',');
            z = hh.Count() - 1;
            for (int i = 0; i < z; i++)
            {

                string dl = System.IO.File.ReadAllText(path + "\\" + hh[i] + ".txt");
                string[] d = dl.Split('|');
                if (o == 0)
                {
                    ddt.Columns.Add("No", typeof(int));
                    ddt.Columns.Add("Bank Name", typeof(string));
                    ddt.Columns.Add("Card Number", typeof(string));
                    ddt.Columns.Add("Expiry Date", typeof(string));
                    ddt.Columns.Add("CCV number", typeof(string));
                    ddt.Columns.Add("Account number", typeof(string));
                    ddt.Columns.Add("Amount", typeof(string));
                    ddt.Columns.Add("Order Date", typeof(string));
                    ddt.Columns.Add("Order", typeof(string));
                    zz++;
                    o += 1;
                }
              
                ddt.Rows.Add(x, d[0], d[1], d[2], d[3], d[4],"Rs."+d[5],d[6],"Debit Card");

                x += 1;




                // return dt;

            }

           x = 1;

            o = 0;
            return ddt;
            
        }

       
    }  
}
