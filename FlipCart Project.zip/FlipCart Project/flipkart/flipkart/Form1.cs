﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using System.IO;
namespace flipkart
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }
       
        private void Form1_Load(object sender, EventArgs e)
        {
            t.X = -250;
            t.Y = 239;
            groupBox5.Location = t;
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Remove(tabPage3);
            tabControl1.TabPages.Remove(tabPage4);
            tabControl1.TabPages.Remove(tabPage5);
            tabControl1.TabPages.Remove(tabPage6);
            tabControl1.TabPages.Remove(tabPage7);
            tabControl1.TabPages.Remove(tabPage8);
            tabControl1.TabPages.Remove(tabPage9); 

        }
        #region listboxlocation
        int i=0,j=0,k=0,l=0,m=0;
        private void label3_MouseMove_1(object sender, MouseEventArgs e)
        {
            listBox1.Visible = true;
            listBox2.Visible = false;
            listBox3.Visible = false;
            listBox4.Visible = false;
            listBox5.Visible = false;
            if (Directory.Exists("E:\\oopsprojects\\product\\" + label3.Text))
            {
                if (i == 0)
                {
                    string ss = pro.fileread("E:\\oopsprojects\\product\\" + label3.Text);
                    string[] o = ss.Split(',');
                    int nn = o.Count() - 2;
                    for (int ii = 0; ii <= nn; ii++)
                    {
                        listBox1.Items.Add(o[i]);
                        i++;

                    }

                }
            }
     
        }

        private void label4_MouseMove_1(object sender, MouseEventArgs e)
        {
            listBox1.Visible = false;
            listBox2.Visible = true;
            listBox3.Visible = false;
            listBox4.Visible = false;
            listBox5.Visible = false;
               if (Directory.Exists("E:\\oopsprojects\\product\\" + label4.Text))
            {
                if (j == 0)
                {
                    string ss = pro.fileread("E:\\oopsprojects\\product\\" + label4.Text);
                    string[] o = ss.Split(',');
                    int nn = o.Count() - 2;
                    for (int ii = 0; ii <= nn; ii++)
                    {
                        listBox2.Items.Add(o[j]);
                        j++;

                    }
                }
            }
           
     

        }
        string lis;
        private void label5_MouseMove_1(object sender, MouseEventArgs e)
        {
            listBox1.Visible = false;
            listBox2.Visible = false;
            listBox3.Visible = true;
            listBox4.Visible = false;
            listBox5.Visible = false;
            if (Directory.Exists("E:\\oopsprojects\\product\\" + label5.Text))
            {
                if (k == 0)
                {
                    string ss = pro.fileread("E:\\oopsprojects\\product\\" + label5.Text);
                    string[] o = ss.Split(',');
                    int nn = o.Count() - 2;
                    for (int ii = 0; ii <= nn; ii++)
                    {
                        listBox3.Items.Add(o[k]);

                        k++;
                    }

                }
            }
    
        }

        private void label6_MouseMove_1(object sender, MouseEventArgs e)
        {
            listBox1.Visible = false;
            listBox2.Visible = false;
            listBox3.Visible = false;
            listBox4.Visible = true;
            listBox5.Visible = false;
         if (Directory.Exists("E:\\oopsprojects\\product\\" + label6.Text))
            {
                if (l == 0)
                {
                    string ss = pro.fileread("E:\\oopsprojects\\product\\" + label6.Text);
                    string[] o = ss.Split(',');
                    int nn = o.Count() - 2;
                    for (int ii = 0; ii <= nn; ii++)
                    {
                        listBox4.Items.Add(o[l]);
                        l++;

                    }
                }
            }
      
        }

        private void label7_MouseMove_1(object sender, MouseEventArgs e)
        {
            listBox1.Visible = false;
            listBox2.Visible = false;
            listBox3.Visible = false;
            listBox4.Visible = false;
            listBox5.Visible = true;
          if (Directory.Exists("E:\\oopsprojects\\product\\" + label7.Text))
            {
                if (m == 0)
                {
                    string ss = pro.fileread("E:\\oopsprojects\\product\\" + label7.Text);
                    string[] o = ss.Split(',');
                    int nn = o.Count() - 2;
                    for (int ii = 0; ii <= nn; ii++)
                    {
                        listBox5.Items.Add(o[m]);
                        m++;

                    }
                }
            }
         
        }

      
        #endregion

        private void button3_Click(object sender, EventArgs e)
        {
            openFileDialog1.ShowDialog();
            textBox6.Text = openFileDialog1.FileName;
            label13.Image = Image.FromFile(textBox6.Text);
            
        }
        flip pro = new flip();
        private void button2_Click(object sender, EventArgs e)
        {
            textBox7.Text.ToUpper();
            
            if (label13.Image.Size.Height <= 500 && label13.Image.Size.Width <= 500)
            {
                i = 0; j = 0; k = 0; l = 0; m = 0;
                //label13.Image = Image.FromFile(textBox6.Text);
                Directory.CreateDirectory("E:\\oopsprojects\\product\\" + comboBox1.SelectedItem);
                Directory.CreateDirectory("E:\\oopsprojects\\product\\" + comboBox1.SelectedItem + "\\" + textBox7.Text);
                Directory.CreateDirectory("E:\\oopsprojects\\product\\" + comboBox1.SelectedItem + "\\" + textBox7.Text + "\\" + textBox3.Text);
                Directory.CreateDirectory("E:\\oopsprojects\\product\\" + comboBox1.SelectedItem + "\\" + textBox7.Text + "\\" + textBox3.Text);
                // DirectoryInfo kk = new DirectoryInfo("E:\\oopsprojects\\product\\" + comboBox1.SelectedItem+"\\"+textBox7.Text);
                // kk.CreateSubdirectory(textBox3.Text);
                pro.filewrite("E:\\oopsprojects\\product\\" + comboBox1.SelectedItem + "\\" + textBox7.Text + "\\" + textBox3.Text + "\\" + textBox8.Text + ".txt", textBox7.Text, textBox3.Text, textBox8.Text, textBox4.Text, textBox5.Text, textBox6.Text);
            }
            else
            {
                MessageBox.Show("Images Size is Too large");
                //DialogResult a = new DialogResult();
                //a = MessageBox.Show("Do u want resize Your Image", "info", MessageBoxButtons.YesNo);
                //if (a==DialogResult.Yes)
                //{

                //    label17.Visible = true;
                //    label18.Visible = true;
                //    textBox9.Visible = true;
                //    textBox10.Visible = true;
                //    button11.Visible = true;

                //   // MessageBox.Show("Height="+Convert.ToInt64(label13.Image.Height).ToString() + "Width="+Convert.ToInt64(label13.Image.Width).ToString());
               // }
            }
        }
     
        string au;
        private void textBox7_TextChanged(object sender, EventArgs e)
        {
           
        }
        string z;
        string co;
        AutoCompleteStringCollection ac = new AutoCompleteStringCollection();
        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

            if (comboBox1.SelectedItem == "ELECTRONICS")
            {
                co = comboBox1.SelectedItem.ToString();
            }
            else if (comboBox1.SelectedItem == "BABY_KIDS")
            {
                co = comboBox1.SelectedItem.ToString();
            }
            else if (comboBox1.SelectedItem == "PERSONAL USE")
            {
                co = comboBox1.SelectedItem.ToString();
            }
            else if (comboBox1.SelectedItem == "BOOKS_MEDIA")
            {
                co = comboBox1.SelectedItem.ToString();
            }
            else if (comboBox1.SelectedItem == "HOME APPLIANCES")
            {
                co = comboBox1.SelectedItem.ToString();
            }
                DirectoryInfo d = new DirectoryInfo("E:\\oopsprojects\\product\\" + co);
                if (Directory.Exists("E:\\oopsprojects\\product\\" + co))
                {
                    foreach (DirectoryInfo item in d.GetDirectories())
                    {
                        au = item.ToString();
                        ac.Add(au);
                    }
                    textBox7.AutoCompleteMode = AutoCompleteMode.SuggestAppend;
                    textBox7.AutoCompleteSource = AutoCompleteSource.CustomSource;
                    textBox7.AutoCompleteCustomSource = ac;
                
                
            }           
        }

        private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
        {
           

        }

       
       

        private void button5_Click_1(object sender, EventArgs e)
        {
            DataTable ddd = new DataTable();
            ddd.Columns.Add("image", typeof(Image));
            ddd.Rows.Add(Image.FromFile("E:\\hh.jpg"));
            dataGridView2.DataSource = ddd;
            listBox1.Visible = false;
            listBox2.Visible = false;
            listBox3.Visible = false;
            listBox4.Visible = false;
            listBox5.Visible = false;
            tabControl1.TabPages.Remove(tabPage4);
            tabControl1.TabPages.Insert(0, tabPage2);
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                if (e.ColumnIndex == 2)
                {
                    if (dataGridView1.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                    {
                        tabControl1.TabPages.Remove(tabPage4);
                        tabControl1.TabPages.Insert(0, tabPage5);
                        dataGridView3.DataSource = pro.filedrd("E:\\oopsprojects\\product\\" + lbl + "\\" + lis + "\\" + dataGridView1.Rows[e.RowIndex].Cells[1].Value.ToString());

                    }
                    else
                        MessageBox.Show("no items selecter");
                }
            }

        }


        string lbl;
        private void listBox2_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            lbl = "";
            lbl = label4.Text;
            lis = "";
            lis = listBox2.SelectedItem.ToString();
            if (Directory.Exists("E:\\oopsprojects\\product\\" + label4.Text + "\\" + listBox2.SelectedItem))
            {
                tabControl1.TabPages.Remove(tabPage2);
                tabControl1.TabPages.Insert(0, tabPage4);
                dataGridView1.DataSource = pro.datagrid("E:\\oopsprojects\\product\\" + label4.Text + "\\" + listBox2.SelectedItem);
            }


        }

     

        private void listBox3_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            lbl = "";
            lbl = label5.Text;
            lis = "";
            lis = listBox3.SelectedItem.ToString();
            if (Directory.Exists("E:\\oopsprojects\\product\\" + label5.Text + "\\" + listBox3.SelectedItem))
            {
                tabControl1.TabPages.Remove(tabPage2);
                tabControl1.TabPages.Insert(0, tabPage4);
                dataGridView1.DataSource = pro.datagrid("E:\\oopsprojects\\product\\" + label5.Text + "\\" + listBox3.SelectedItem);
            }

        }

        private void listBox4_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            lbl = "";
            lbl = label6.Text;
            lis = "";
            lis = listBox4.SelectedItem.ToString();
            if (Directory.Exists("E:\\oopsprojects\\product\\" + label6.Text + "\\" + listBox4.SelectedItem))
            {
                tabControl1.TabPages.Remove(tabPage2);
                tabControl1.TabPages.Insert(0, tabPage4);
                dataGridView1.DataSource = pro.datagrid("E:\\oopsprojects\\product\\" + label6.Text + "\\" + listBox4.SelectedItem);
            }

        }

        private void listBox5_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            lbl = "";
            lbl = label7.Text;
            lis = "";
            lis = listBox5.SelectedItem.ToString();
            if (Directory.Exists("E:\\oopsprojects\\product\\" + label7.Text + "\\" + listBox5.SelectedItem))
            {
                tabControl1.TabPages.Remove(tabPage2);
                tabControl1.TabPages.Insert(0, tabPage4);
                dataGridView1.DataSource = pro.datagrid("E:\\oopsprojects\\product\\" + label7.Text + "\\" + listBox5.SelectedItem);
            }

        }

        private void listBox1_SelectedIndexChanged_1(object sender, EventArgs e)
        {
            lbl = "";
            lbl = label3.Text;
            lis = "";
            lis = listBox1.SelectedItem.ToString();
            if (Directory.Exists("E:\\oopsprojects\\product\\" + label3.Text + "\\" + listBox1.SelectedItem))
            {
                tabControl1.TabPages.Remove(tabPage2);
                tabControl1.TabPages.Insert(0, tabPage4);
                dataGridView1.DataSource = pro.datagrid("E:\\oopsprojects\\product\\" + label3.Text + "\\" + listBox1.SelectedItem);
            }

        }

        private void textBox7_KeyPress(object sender, KeyPressEventArgs e)
        {
            
        }

        private void dataGridView2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                if (dataGridView2.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                {
                   
                    tabControl1.TabPages.Remove(tabPage5);
                    tabControl1.TabPages.Insert(0, tabPage6);
                }
            }
        }


       

        private void button4_Click(object sender, EventArgs e)
        {
            if (textBox11.Text != "" && textBox12.Text != "" && textBox13.Text != "" && textBox14.Text != "")
            {
                TextWriter a;
                Directory.CreateDirectory("E:\\oopsprojects\\product\\userinfo\\" + textBox11.Text);
                a = File.CreateText("E:\\oopsprojects\\product\\userinfo\\" + textBox11.Text + "\\" + textBox12.Text + ".txt");
                a.WriteLine(textBox11.Text+","+ textBox12.Text+","+textBox13.Text+","+textBox14.Text);
                a.Flush();
                a.Close();
                groupBox1.Visible = false;
                MessageBox.Show("Sucessfully Registered");
                panel2.Enabled = true;
            }
            else
            {
                MessageBox.Show("Information not completed");
            }
        }

        

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void label26_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Insert(0, tabPage1);
            label25.Text = "";
            listBox1.Visible = false;
            listBox2.Visible = false;
            listBox3.Visible = false;
            listBox4.Visible = false;
            listBox5.Visible = false;
            textBox1.Clear();
            textBox2.Clear();

        }

      

     

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

      

     
        private void label27_Click(object sender, EventArgs e)
        {
            groupBox1.Visible = false;
            panel2.Enabled = true;
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (textBox6.Text != "")
            {
                label13.Visible = true;
            }
            else
            {
                MessageBox.Show("No Image");
            }
        }

        private void dataGridView3_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex != -1)
            {
                if (e.ColumnIndex == 7)
                {
                    if (dataGridView3.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
                    {
                        label37.Text = dataGridView3.Rows[e.RowIndex].Cells[1].Value.ToString();
                        label38.Text = dataGridView3.Rows[e.RowIndex].Cells[2].Value.ToString();
                        label39.Text = dataGridView3.Rows[e.RowIndex].Cells[3].Value.ToString();
                        label53.Text = dataGridView3.Rows[e.RowIndex].Cells[4].Value.ToString();
                        label40.Text = dataGridView3.Rows[e.RowIndex].Cells[5].Value.ToString();
                        label42.Text = "2 days";
                        tabControl1.TabPages.Remove(tabPage5);
                        tabControl1.TabPages.Insert(0, tabPage6);
                        string dl = System.IO.File.ReadAllText("E:\\oopsprojects\\product\\" + lbl + "\\" + lis + "\\" + label38.Text + "\\" + label39.Text + ".txt");
                        string[] d = dl.Split('|');
                        label41.Image = Image.FromFile(d[5]);
                        string dld = System.IO.File.ReadAllText("E:\\oopsprojects\\product\\userinfo\\" + textBox1.Text + "\\" + textBox2.Text + ".txt");
                        string[] dd = dld.Split(',');
                        textBox15.Text = dd[0];
                        textBox16.Text = dd[2];
                        textBox17.Text = dd[3];
                   
                    }
                }
            }

        }

      

        private void label34_Click(object sender, EventArgs e)
        {

        }
        Point t = new Point();
        private void timer1_Tick(object sender, EventArgs e)
        {
            if (t.X < -2)
            {
                t.X += 3;
                groupBox5.Location = t;
            }
            else
            {
                timer1.Enabled = false;
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            label1.Visible = true;
            textBox1.Visible = true;
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label1.Visible = false;
            textBox1.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (radioButton1.Checked == true)
            {
                if (textBox1.Text != "" && textBox2.Text != "")
                {
                    if (Directory.Exists("E:\\oopsprojects\\product\\userinfo\\" + textBox1.Text) && File.Exists("E:\\oopsprojects\\product\\userinfo\\" + textBox1.Text + "\\" + textBox2.Text + ".txt"))
                    {
                        textBox15.Clear();
                        textBox16.Clear();
                        textBox17.Clear();
                        tabControl1.TabPages.Remove(tabPage1);
                        tabControl1.TabPages.Insert(0, tabPage2);
                        label25.Text = "Hi.." + textBox1.Text;
                    }
                    else
                    {
                        MessageBox.Show("Invalid User");
                    }
                }
                else
                {
                    MessageBox.Show("Information Not Completed");
                }
            }
            else
            {
                if (radioButton2.Checked == true)
                {
                    if (textBox2.Text == "admin")
                    {
                        tabControl1.TabPages.Remove(tabPage1);
                        tabControl1.TabPages.Insert(0, tabPage3);

                    }
                    else
                        MessageBox.Show("Invalid");
                }
                else
                    MessageBox.Show("Invalid");
            }
        }

        private void label24_Click(object sender, EventArgs e)
        {
           panel2.Enabled = false;
           groupBox1.Visible = true;
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {
            dataGridView4.DataSource = "";
            groupBox4.Visible = true;
            //int s = label13.Image.Height;
            //int v = label13.Image.Width;
            //int newWidth = label13.Image.Width * v / 100;
            //int newHeight = label13.Image.Height * s / 100;
            //var h = ((float)label13.Image.Width / (float)v);
            //var w = ((float)label13.Image.Height / (float)s);
            //var percentage = Math.Max(h, w);
            //var width = (int)Math.Max(s * percentage, label13.Image.Width);
            //var height = (int)Math.Max(v * percentage, label13.Image.Height);
            //var resizedBmp = new Bitmap(width, height);
            //var graphics = Graphics.FromImage((Image)resizedBmp);

            //graphics.DrawImage(label13.Image, 0, 0, Convert.ToInt32(textBox10.Text), Convert.ToInt32(textBox9.Text));

            //label13.Image = resizedBmp;//new Size(Convert.ToInt32(textBox10.Text),Convert.ToInt32(textBox9.Text));
            //label17.Visible = false;
            //label18.Visible = false;
            //textBox9.Visible = false;
            //textBox10.Visible = false;
            //button11.Visible = false;
        }

                int cc,a,b;
        private void button9_Click(object sender, EventArgs e)
        {
            if (textBox18.Text != "")
            {
                if((radioButton3.Checked == true && checkBox1.Checked==true)||(radioButton4.Checked == true && checkBox1.Checked==true))
                {
                textBox23.Text=label40.Text;
               
                a = Convert.ToInt32(label53.Text);
                b = Convert.ToInt32(textBox18.Text);                
                            
                if (radioButton4.Checked == true&&checkBox1.Checked==true)
                {
                    if (a >= b&&a!=0)
                    {
                        tabControl1.TabPages.Remove(tabPage6);
                        tabControl1.TabPages.Insert(0, tabPage7);

                    }
                    else if (a == 0)
                    {
                        MessageBox.Show("Product No Stock");
                    }
                    else
                    {
                        MessageBox.Show("Enter Valid Quantity");
                    }
                }
                if (radioButton3.Checked == true && checkBox1.Checked == true)
                {
                    if (a >= b)
                    {

                        groupBox3.Visible = true;
                    }
                    else if (a == 0)
                    {
                        MessageBox.Show("Product No Stock");
                    }

                    else
                    {
                        MessageBox.Show("Enter Valid Quantity");
                    }
                }
            
                     }
                else
                {
                    MessageBox.Show("Information not Completed");
                }
            }
            else
            {
                MessageBox.Show("Enter Quantity");
            }
           
         
          }

        private void label55_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox7.Clear();
            textBox3.Clear();
            textBox8.Clear();
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            tabControl1.TabPages.Remove(tabPage3);
            tabControl1.TabPages.Insert(0, tabPage1);
        }

       
        private void label57_Click(object sender, EventArgs e)
        {
            listBox1.Visible = false;
            listBox2.Visible = false;
            listBox3.Visible = false;
            listBox4.Visible = false;
            listBox5.Visible = false;
            tabControl1.TabPages.Remove(tabPage4);
            tabControl1.TabPages.Insert(0, tabPage2);
        }

        private void label58_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            listBox1.Visible = false;
            listBox2.Visible = false;
            listBox3.Visible = false;
            listBox4.Visible = false;
            listBox5.Visible = false;
            tabControl1.TabPages.Remove(tabPage4);
            tabControl1.TabPages.Insert(0, tabPage1);

        }
        private void label59_Click(object sender, EventArgs e)
        {
            listBox1.Visible = false;
            listBox2.Visible = false;
            listBox3.Visible = false;
            listBox4.Visible = false;
            listBox5.Visible = false;
            tabControl1.TabPages.Remove(tabPage5);
            tabControl1.TabPages.Insert(0, tabPage2);
        
        }

        private void label60_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Remove(tabPage5);
            tabControl1.TabPages.Insert(0, tabPage1);
            textBox1.Clear();
            textBox2.Clear();
        }

        private void label61_Click(object sender, EventArgs e)
        {
            tabControl1.TabPages.Remove(tabPage5);
            tabControl1.TabPages.Insert(0, tabPage4);

        }

        private void label63_Click(object sender, EventArgs e)
        {
            listBox1.Visible = false;
            listBox2.Visible = false;
            listBox3.Visible = false;
            listBox4.Visible = false;
            listBox5.Visible = false;
            tabControl1.TabPages.Remove(tabPage6);
            tabControl1.TabPages.Insert(0, tabPage2);
        }

        private void label62_Click(object sender, EventArgs e)
        {
            
            tabControl1.TabPages.Remove(tabPage6);
            tabControl1.TabPages.Insert(0, tabPage4);

        }

        private void label64_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            tabControl1.TabPages.Remove(tabPage6);
            tabControl1.TabPages.Insert(0, tabPage1);
        }

      

      

        private void button5_Click(object sender, EventArgs e)
        {
            if (comboBox2.SelectedItem != "" && textBox19.Text != "" && comboBox3.SelectedItem != "" && comboBox4.SelectedItem != "" && textBox20.Text != "" && textBox21.Text != "" && textBox22.Text != "")
            {
                listBox1.Visible = false;
                listBox2.Visible = false;
                listBox3.Visible = false;
                listBox4.Visible = false;
                listBox5.Visible = false;
                textBox18.Clear();
                radioButton3.Checked = false;
                radioButton4.Checked = false;
                checkBox1.Checked = false;
                TextWriter g;
                g = File.CreateText("E:\\oopsprojects\\delivery\\card\\" + comboBox2.SelectedItem + ".txt");
                g.WriteLine(comboBox2.SelectedItem + "|" + textBox19.Text + "|" + comboBox3.SelectedItem + "-" + comboBox4.SelectedItem + "|" + textBox20.Text + "|" + textBox21.Text +"|" + textBox23.Text+"|"+DateTime.Now.ToShortDateString());
                g.Flush();
                g.Close();
                timer2.Enabled = true;
                label74.Visible = true;
                label75.Visible = true;

            }
            else
            {
                MessageBox.Show("Informarion Not Completed","Alert");
            }
        }
        int ii = 0;
        private void timer2_Tick(object sender, EventArgs e)
        {
            if (ii < 50)
            {
              
                ii++;
            }
            else
            {
                timer2.Enabled=false;
                label74.Visible = false;
                label75.Visible = false;
                MessageBox.Show("Transaction Sucessfully Completed");
                tabControl1.TabPages.Remove(tabPage7);
                tabControl1.TabPages.Insert(0, tabPage2);
               // textBox1.Clear();
               // textBox2.Clear();
                textBox19.Clear();
                textBox20.Clear();
                textBox21.Clear();
                textBox22.Clear();
                textBox23.Clear();
            }

        }

        private void groupBox2_Enter(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void label80_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            textBox19.Clear();
            textBox20.Clear();
            textBox21.Clear();
            textBox22.Clear();
            textBox23.Clear();
            tabControl1.TabPages.Remove(tabPage7);
            tabControl1.TabPages.Insert(0, tabPage1);
        }

        private void label81_Click(object sender, EventArgs e)
        {
            textBox1.Clear();
            textBox2.Clear();
            tabControl1.TabPages.Remove(tabPage8);
            tabControl1.TabPages.Insert(0, tabPage1);

        }

        private void label79_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("http://www.facebook.com/");
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Insert(0, tabPage8);
        }

        private void label72_Click(object sender, EventArgs e)
        {
            webBrowser1.Navigate("http://www.twitter.com/");
            tabControl1.TabPages.Remove(tabPage2);
            tabControl1.TabPages.Insert(0, tabPage8);

        }

        private void label83_Click(object sender, EventArgs e)
        {
            webBrowser1.Refresh();
        }

        private void label84_Click(object sender, EventArgs e)
        {
            webBrowser1.GoForward();
        }

        private void label82_Click(object sender, EventArgs e)
        {
            webBrowser1.GoBack();
        }

        private void label85_Click(object sender, EventArgs e)
        {
            listBox1.Visible = false;
            listBox2.Visible = false;
            listBox3.Visible = false;
            listBox4.Visible = false;
            listBox5.Visible = false;
            tabControl1.TabPages.Remove(tabPage8);
            tabControl1.TabPages.Insert(0, tabPage2);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (a >= b && a != 0)
            {
                string dl = System.IO.File.ReadAllText("E:\\oopsprojects\\product\\" + lbl + "\\" + lis + "\\" + label38.Text + "\\" + label39.Text + ".txt");
                string[] d = dl.Split('|');
                cc = a - b;
                string dd = cc.ToString();
                TextWriter s;
                s = File.CreateText("E:\\oopsprojects\\product\\" + lbl + "\\" + lis + "\\" + label38.Text + "\\" + label39.Text + ".txt");
                s.WriteLine(lis + "|" + label38.Text + "|" + label39.Text + "|" + dd + "|" + label40.Text + "|" + d[5] + "|" + 0);
                s.Flush();
                s.Close();
            }
            if (textBox24.Text != "" && textBox25.Text != "" && textBox26.Text != "" && textBox27.Text != "")
            {
                listBox1.Visible = false;
                listBox2.Visible = false;
                listBox3.Visible = false;
                listBox4.Visible = false;
                listBox5.Visible = false;
                string dl = System.IO.File.ReadAllText("E:\\oopsprojects\\product\\" + lbl + "\\" + lis + "\\" + label38.Text + "\\" + label39.Text + ".txt");
                string[] d = dl.Split('|');
                cc = a - b;
                string dd = cc.ToString();
                TextWriter s;
                s = File.CreateText("E:\\oopsprojects\\product\\" + lbl + "\\" + lis + "\\" + label38.Text + "\\" + label39.Text + ".txt");
                s.WriteLine(lis + "|" + label38.Text + "|" + label39.Text + "|" + dd + "|" + label40.Text + "|" + d[5] + "|" + 0);
                s.Flush();
                s.Close();
                TextWriter g;
                g = File.CreateText("E:\\oopsprojects\\delivery\\cash\\"+textBox24.Text+".txt");
                g.WriteLine(textBox24.Text + "|" + textBox25.Text + "|" + textBox26.Text + "|" + textBox27.Text + "|" + label40.Text + "|" + DateTime.Now.ToShortDateString());
                g.Flush();
                g.Close();
                MessageBox.Show("Your Product Will Be Delivery With In " + label42.Text , "info");
                tabControl1.TabPages.Remove(tabPage6);
                tabControl1.TabPages.Insert(0, tabPage2);
                groupBox3.Visible = false;
                textBox18.Clear();
                radioButton3.Checked = false;
                radioButton4.Checked = false;
                checkBox1.Checked = false;
            }
            else
            {
                MessageBox.Show("Information not Completed");
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (radioButton6.Checked == true)
            {
                dataGridView4.DataSource = pro.fimg("E:\\oopsprojects\\delivery\\cash");
                groupBox4.Visible = false;
            }
            else if (radioButton5.Checked == true)
            {
                dataGridView4.DataSource = pro.fcsh("E:\\oopsprojects\\delivery\\card");
                groupBox4.Visible = false;
            }
            else
            {
                MessageBox.Show("Information not Completed");

            }
        }

        private void button10_Click(object sender, EventArgs e)
        {
            if (textBox9.Text != "" && textBox10.Text != "")
            {
                MessageBox.Show("Sucessfully Posted");
                timer3.Enabled = true;
            }
            else
            {
                MessageBox.Show("Information not Completed");
             }
          
        }

        private void label56_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            textBox10.Clear();
            textBox9.Clear();
           
        }

        private void label45_Click(object sender, EventArgs e)
        {

        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            if (t.X >- 250)
            {
                t.X -= 3;
                groupBox5.Location = t;
            }
            else
            {
                timer3.Enabled = false;
            }
        }

        private void label101_Click(object sender, EventArgs e)
        {
            timer3.Enabled = true;
        }

        private void listBox4_SelectedIndexChanged(object sender, EventArgs e)
        {
            lbl = "";
            lbl = label6.Text;
            lis = "";
            lis = listBox4.SelectedItem.ToString();
            if (Directory.Exists("E:\\oopsprojects\\product\\" + label6.Text + "\\" + listBox4.SelectedItem))
            {
                tabControl1.TabPages.Remove(tabPage2);
                tabControl1.TabPages.Insert(0, tabPage4);
                dataGridView1.DataSource = pro.datagrid("E:\\oopsprojects\\product\\" + label6.Text + "\\" + listBox4.SelectedItem);
            }

        }

       

       

     

       
        

       

     

       
    }
}
